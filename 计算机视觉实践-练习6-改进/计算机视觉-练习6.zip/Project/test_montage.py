import datetime
import os
import tkinter
from tkinter import filedialog

import cv2
import torch
import yaml
from icecream import ic

from FPRegistration import util
from FPRegistration.DataGroup import DataGroup
from FPRegistration.ImageGroup import ImageGroup
from FPRegistration.Register import SuperglueReg
from FPRegistration.log import setup_log


def get_files():
    # 实现用户可以通过文件选取的方式指定原始文件
    root = tkinter.Tk()
    root.withdraw()
    Fpath = filedialog.askopenfilenames()
    print(Fpath)
    return Fpath


def get_dir():
    # 实现用户可以通过文件选取的方式指定原始文件
    root = tkinter.Tk()
    root.withdraw()
    Fpath = filedialog.askdirectory()
    print(Fpath)
    return Fpath


def match(dataGroup, save_dir):
    # match_order = [(0, 1)]
    # match_order = [(0, 1), (0, 2), (3, 7), (3, 8), (4,5), (4, 6), (0,3), (0,5)]
    # match_order = [(0, 1), (0, 2), (7,3), (0,7), (0,8),  (0,5),(0,6),(0,4)]
    # match_order=[(0,1),(0,2),(0,4),(0,3)]
    # flag = superglue.montage_with_order_affine(dataGroup)
    #superglue.montage_with_order(dataGroup)
    superglue.montage_with_order_affine(dataGroup)
    eye_pos = dataGroup.calc_eye_pos_()
    save_path = save_dir + eye_pos
    # dataGroup.warp_img()
    dataGroup.warp_img_thread_pool()
    dataGroup.write_img(save_path)

    # assert (dataGroup.img_groups[1].iwac) is None or np.sum(dataGroup.img_groups[1].iwac.img==dataGroup.img_groups[1].img)!=dataGroup.img_groups[1].img.size

    dataGroup.write_merged_img(save_path, 'final.jpg')
    #dataGroup.write_merged_img_stitcher(dataGroup.master_id, save_path)

    print('time_set_img', dataGroup.time_set_img.total_seconds())
    print('time_order', dataGroup.time_order.total_seconds())
    print('time_warp', dataGroup.time_warp.total_seconds())
    print('time_merge', dataGroup.time_merge.total_seconds())
    print('time_kp_detect', dataGroup.time_kp_detect.total_seconds())
    print('time_match', dataGroup.time_match.total_seconds())
    print('time_write', dataGroup.time_write.total_seconds())

    #     save_paths = dataGroup.save_img(img_groups, save_dir, merged_img)
    #     code = 1
    #     print('warp', dataGroup.time_warp.total_seconds())
    #     print('save', dataGroup.time_save.total_seconds())
    #     print('merge', dataGroup.time_merge.total_seconds())
    # else:
    #     save_paths = []
    #     code = 2
    return 1, save_paths, eye_pos


# def match_twice(dataGroup,save_path):
#     flag = superglue.match_with_master_new(0, dataGroup)
#     if flag:
#         outputs, img_names = dataGroup.get_output(True)
#     dataGroup.set_img()
if __name__ == '__main__':
    torch.set_grad_enabled(False)
    ic.disable()
    # global_config.DO_DEBUG = True
    print('start')
    f = open(r'../Resources/config.yaml', encoding='utf-8')
    config = yaml.safe_load(f)
    f.close()
    config = util.get_default_config(config)
    logger = setup_log(config['log_dir'], 'common')
    ImageGroup.weight_template = util.imread(os.path.join(config['weights_dir'], 'weight.png'), cv2.IMREAD_GRAYSCALE)

    imgs = []
    img_paths = get_files()
    config['device'] = 'cpu'
    superglue = SuperglueReg(
        config=config,
        logger=logger,
        do_debug=False
        # 以上参数除了tar_size默认-1，别的都设置了如上的默认参数，调用时不改可不写
    )
    sub_config = config.copy()
    sub_config['task_id'] = '0'
    sub_config['fit_size'] = 400
    # sub_config['tar_size'] = 512
    sub_config['tar_size'] = 1500
    # sub_config['tar_size'] = -1
    sub_config['group_num'] = 2
    sub_config['do_exchange'] = True
    # sub_config['do_display'] = True
    sub_config['do_display'] = False

    time = datetime.datetime.now()
    dataGroup = DataGroup(sub_config)
    change_flag = dataGroup.set_img_(img_paths, superglue.model_vegan, superglue.model_bj)
    ic(change_flag)
    # superglue.set_img(dataGroup)
    # superglue.point_detect_all(dataGroup)
    # superglue.point_detect_all_threads(dataGroup, change_flag)
    superglue.point_detect_all_thread_pool(dataGroup, change_flag)
    # for i, img_group in enumerate(dataGroup.img_groups):
    #     util.imwrite('outs/no_border/' + str(i) + '.jpg', img_group.img, '.jpg')
    # for img_group in dataGroup.img_groups:
    #     img=util.draw_keypoints(img_group.I,img_group.detected_data['keypoints'])
    #     cv2.imshow('img',img)
    #     cv2.waitKey()

    save_path = 'outs'
    save_paths = []
    eye_poses = []
    if sub_config['group_num'] == 1:
        code, save_paths, eye_pos = match(dataGroup, save_path)
        eye_poses.append(eye_pos)
    else:
        for i in range(sub_config['group_num']):
            sub_save_path = os.path.join(save_path, i.__str__())
            if i > 0:
                dataGroup = dataGroup.get_sub_dataGroup()
            if len(dataGroup.img_groups) < 1:
                break
            sub_code, sub_save_paths, eye_pos = match(dataGroup, sub_save_path)
            for j, tform in enumerate(dataGroup.tforms):
                if tform is None:
                    continue
                # print(dataGroup.img_paths[0],dataGroup.img_paths[j],tform.shear,tform.scale[0]/tform.scale[1])s
            if sub_code == 1:
                code = 1
                save_paths.append(sub_save_paths)
                eye_poses.append(eye_pos)
    print(eye_poses)
    print('total', (datetime.datetime.now() - time).total_seconds())
    # for (img, name) in zip(outputs, img_names):
    #     cv2.imshow(name, img)
    # cv2.waitKey()

# for i, out in enumerate(outs):
#     if out is None:
#         continue
#     cv2.imshow(img_paths[i], out)
# cv2.waitKey()
