# -*- coding:utf-8 -*-
import os
# from prefetch_generator import BackgroundGenerator

import torch
import torch.nn as nn

import FPRegistration.vegan.networks_for_pix2pixHD as networks

""" set flags / seeds """
torch.backends.cudnn.benchmark = True
os.environ['CUDA_VISIBLE_DEVICES'] = '3'


class Pix2PixModel(nn.Module):
    def __init__(self):
        super(Pix2PixModel, self).__init__()
        self.netG = networks.define_G(3, 1, 64, 'global',
                                      n_downsample_global=4, n_blocks_global=9, n_local_enhancers=1,
                                      n_blocks_local=3, norm = 'instance', gpu_ids=0)

        # self.loss_fn_vgg = lpips.LPIPS(net='vgg')

        self.netD = self.netD = networks.define_D(4, 64, 3, 'instance', False, 2, True, gpu_ids=0)

        # define loss functions
        # self.criterionGAN = networks.GANLoss(use_lsgan=True, tensor=torch.cuda.FloatTensor)
        # self.criterionFeat = torch.nn.L1Loss()
        # self.criterionVGG = networks.VGGLoss()

    def criterion_D(self, fake_B, real_B, real_A):
        fake_in = torch.cat([fake_B,real_A], dim=1)
        pred_fake = self.netD(fake_in.detach())
        loss_D_fake = self.criterionGAN(pred_fake, target_is_real=False)

        real_in = torch.cat([real_B,real_A], dim=1)
        pred_real = self.netD(real_in)
        loss_D_real = self.criterionGAN(pred_real, target_is_real=True)

        loss_D = (loss_D_fake + loss_D_real) * 0.5
        return [loss_D]

    def criterion_G(self, fake_B, real_B, real_A):

        fake_in = torch.cat([fake_B, real_A], dim=1)
        pred_fake = self.netD(fake_in)
        real_in = torch.cat([real_B,real_A], dim=1)
        pred_real = self.netD(real_in)
        loss_G_GAN = self.criterionGAN(pred_fake, target_is_real=True)

        # GAN feature matching loss
        loss_G_GAN_Feat = 0
        feat_weights = 4.0 / (3 + 1)
        D_weights = 1.0 / 2
        for i in range(2):
            for j in range(len(pred_fake[i])-1):
                loss_G_GAN_Feat += D_weights * feat_weights * \
                    self.criterionFeat(pred_fake[i][j], pred_real[i][j].detach()) * 10

        # VGG feature matching loss
        loss_G_VGG = self.criterionVGG(torch.cat([fake_B, fake_B, fake_B], dim=1), torch.cat([real_B,real_B,real_B], dim=1)) * 10

        loss_G = loss_G_GAN + loss_G_GAN_Feat + loss_G_VGG
        return [loss_G, loss_G_GAN, loss_G_GAN_Feat, loss_G_VGG]


# if __name__ == "__main__":
#     """ Hpyer parameters """
#     parser = argparse.ArgumentParser(description="new pix2pix")
#     parser.add_argument('--experiment_name', type=str, default='gen_pix2pixHD_global_[01]_2')
#     # training option
#     parser.add_argument('--batch_size', type=int, default=1)
#     parser.add_argument('--num_iters', type=int, default=100000)
#     parser.add_argument('--schedule_times', type=int, default=20000)
#     parser.add_argument('--schedule_decay_times', type=int, default=10000)
#     parser.add_argument('--lr_g', type=float, default=0.0001)
#     parser.add_argument('--lr_d', type=float, default=0.0004)
#     parser.add_argument('--eval_iters', type=int, default=1000) # 1000
#     parser.add_argument('--save_iters', type=int, default=20000) # 5000
#     # data option
#     datasetting.get_data_setting(parser)
#     parser.add_argument('--train_folds', nargs='+', type=int, default=[0,1])
#     parser.add_argument('--test_folds', nargs='+', type=int, default=[2,3])
#     parser.add_argument('--result_dir', type=str, default='/home/huangkun/Data/CFP2FFA/dataset_yu/result')
#     parser.add_argument('--test_img_save_dir', type=str, default='test_img')
#     opt = parser.parse_args()
#
#     opt.result_dir = os.path.join(opt.result_dir, opt.experiment_name)
#     if not os.path.exists(opt.result_dir):
#         os.makedirs(opt.result_dir)
#         print_options(parser, opt)
#         shutil.copyfile(os.path.abspath(__file__), os.path.join(opt.result_dir, os.path.basename(__file__)))
#     else:
#         print("result_dir exists: ", opt.result_dir)
#         exit()
#
#     """ device configuration """
#     device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
#
#     """ track of experiments """
#     writer = SummaryWriter(os.path.join(opt.result_dir, 'runs'))
#     print("track view:", os.path.join(opt.result_dir, 'runs')[3:])
#
#     """ datasets and dataloader """
#     print(opt.train_folds,  opt.test_folds)
#     train_transform = A.Compose([
#         A.Resize(512,512),
#         A.HorizontalFlip(p=0.5),
#         A.RandomRotate90(p=0.5),
#         A.RandomCrop(width=256, height=256),
#     ])
#     test_transform = A.Compose([
#         A.Resize(512,512),
#     ])
#     A_dir = '/home/huangkun/Data/CFP2FFA/dataset_yu/A'
#     B_dir = '/home/huangkun/Data/CFP2FFA/dataset_yu/B'
#     train_dataset = AugmentedDataset(A_dir, B_dir, A_dir,A_dir, opt.train_folds, train_transform)
#     train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=opt.batch_size, shuffle=True,
#                                                num_workers=opt.num_workers, drop_last=False)
#     test_dataset = AugmentedDataset(A_dir, B_dir, A_dir,A_dir, opt.test_folds, test_transform)
#     test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=1, shuffle=False, num_workers=opt.num_workers)
#     print('train_dataset len:', len(train_dataset), 'test_dataset len:', len(test_loader))
#
#     """ instantiate network and loss function"""
#     model = Pix2PixModel(opt)
#     print_network(model, opt)
#
#     """ optimizer and scheduler """
#     optimizer_G = torch.optim.Adam(model.netG.parameters(), lr=opt.lr_g, betas=(0.5, 0.999))
#     optimizer_D = torch.optim.Adam(model.netD.parameters(), lr=opt.lr_d, betas=(0.5, 0.999))
#     if opt.schedule_times:
#         scheduler_G = torch.optim.lr_scheduler.LambdaLR(optimizer_G, lr_lambda=LambdaLR(opt.schedule_times, 0,
#                                                                                         opt.schedule_times - opt.schedule_decay_times).step)
#         scheduler_D = torch.optim.lr_scheduler.LambdaLR(optimizer_D, lr_lambda=LambdaLR(opt.schedule_times, 0,
#                                                                                         opt.schedule_times - opt.schedule_decay_times).step)
#         schedule_iters = opt.num_iters//opt.schedule_times
#         print('scheduler total %d iters from %d iters, iter_size %d' % (opt.schedule_times, opt.schedule_times - opt.schedule_decay_times, schedule_iters))
#
#     """ training part """
#     losses_name = ['loss_D', 'loss_G', 'loss_G_GAN', 'loss_G_GAN_Feat', 'loss_G_VGG']
#     losses_cnt = 0
#     losses_sum = np.zeros(len(losses_name))
#     global_iter = 0
#     model = model.to(device)
#     model.train()
#     pbar = tqdm.tqdm(total=opt.num_iters)
#     while global_iter < opt.num_iters:
#         for _, (real_A, real_B, _, _, _) in enumerate(BackgroundGenerator(train_loader)):
#             real_A = real_A.to(device)
#             real_B = real_B.to(device)
#             # print(real_A.shape, real_B.shape)
#             input = real_A
#             fake_B = model.netG(input)
#             # update D
#             set_requires_grad(model.netD, True)
#             losses_D = model.criterion_D(fake_B, real_B, real_A)
#             optimizer_D.zero_grad()
#             losses_D[0].backward()
#             optimizer_D.step()
#
#             # update G
#             set_requires_grad(model.netD, False)
#             losses_G = model.criterion_G(fake_B, real_B, real_A)
#             optimizer_G.zero_grad()
#             losses_G[0].backward()
#             optimizer_G.step()
#
#             losses_sum = list(map(lambda x, y: x.item() + y, losses_D + losses_G, losses_sum))
#             losses_cnt += real_A.shape[0]
#
#             global_iter += 1
#             pbar.update(1)
#             if opt.schedule_times and global_iter % schedule_iters == 0 :
#                 scheduler_D.step()
#                 scheduler_G.step()
#
#             if global_iter % opt.eval_iters == 0:
#
#                 # write training data
#                 losses_sum = list(map(lambda x: x / losses_cnt, losses_sum))
#                 ave_losses = dict(zip(losses_name, losses_sum))
#                 writer.add_scalars('ave_losses', ave_losses, global_iter)
#                 losses_sum = np.zeros(len(losses_name))
#
#                 train_lpips = model.loss_fn_vgg(fake_B, real_B)
#                 writer.add_scalar('train lpips', train_lpips, global_iter)
#                 train_paras = 'lp_%.3f' % (train_lpips)
#
#                 # model eval
#                 test_lpips = 0
#                 model.eval()
#                 with torch.no_grad():
#                     for _, (real_A, real_B, _, _, _) in enumerate(BackgroundGenerator(test_loader)):
#                         real_A = real_A.to(device)
#                         real_B = real_B.to(device)
#                         input = real_A
#                         fake_B = model.netG(input)
#
#                         test_lpips += model.loss_fn_vgg(fake_B, real_B)
#                 model.train()
#
#                 # write testing data
#                 test_lpips /= len(test_dataset)
#                 writer.add_images('test_real_A', real_A, global_iter)
#                 writer.add_images('test_fake_B', fake_B, global_iter)
#                 writer.add_images('test_real_B', real_B, global_iter)
#                 eval_paras = 'lp_%.3f' % (test_lpips)
#                 # model saving
#                 save_dir = opt.result_dir
#                 if not os.path.exists(save_dir): os.mkdir(save_dir)
#                 if global_iter % opt.save_iters == 0:
#                     state = {'netG': model.netG.state_dict(), 'netD': model.netD.state_dict()}
#                     torch.save(state,
#                                os.path.join(opt.result_dir, 'model_GD_' + str(global_iter) + eval_paras + '.ckpt'))
#
#                 #print log
#                 print('iter: %d' % (global_iter) + ', train: ' + train_paras + ', test: ' + eval_paras)
#
#             if global_iter == opt.num_iters : break
#
#     opt.test_img_save_dir = os.path.join(opt.result_dir, opt.test_img_save_dir)
#     if not os.path.exists(opt.test_img_save_dir): os.mkdir(opt.test_img_save_dir)
#
#     # model_save_path = os.path.join(opt.result_dir,'model_GD_100000lp_0.332.ckpt')
#     # model.netG.load_state_dict(torch.load(model_save_path)['netG'])
#     model.netG.to(device)
#     model.eval()
#     ssim = 0
#     with torch.no_grad():
#         for i, (real_A, real_B, _, _, imgname) in enumerate(test_loader):
#             real_A = real_A.to(device)
#             real_B = real_B.to(device)
#             # labels = label
#             input = real_A
#             fake_B = model.netG(input)
#             img_path = os.path.join(opt.test_img_save_dir, imgname[0][:-4] + '.png')
#             save_image(fake_B, img_path)