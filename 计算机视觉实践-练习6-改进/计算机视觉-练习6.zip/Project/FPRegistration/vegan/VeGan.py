import datetime

import cv2
import torchvision
import torch

from FPRegistration import util
from FPRegistration.vegan.basic_unet import UNet
from torch.utils.data.dataset import Dataset

from FPRegistration.vegan.networks_for_pix2pixHD import GlobalGenerator, get_norm_layer

class DatasetForVeGan(Dataset):
    def __init__(self, imgs, img_paths, size):
        self.imgs = imgs
        self.img_paths = img_paths
        self.size = size


    def __getitem__(self, index):
        img = self.imgs[index]
        # size1=img.shape[:2]
        # bottom,top,left,right=util.calc_blackborder(img)
        # img=img[bottom:top,left:right]
        size = img.shape[:2]
        img = cv2.resize(img, self.size)
        # cv2.imshow('img',img)
        # cv2.waitKey()
        img = torchvision.transforms.ToTensor()(img)

        # return img, self.img_paths[index], torch.tensor(size), torch.tensor((bottom,size1[0]-top,left,size1[1]-right))
        return img, self.img_paths[index], torch.tensor(size), torch.tensor((0,0,0,0))

    def __len__(self):
        return len(self.img_paths)


class VeGan():
    def __init__(self, ve_model_path, ve_model_type, batch_size=2,device='cpu'):
        self.batch_size = batch_size
        if (ve_model_type == 'unet'):
            self.ve_net = UNet(3, 1)
            self.ve_net.load_state_dict(torch.load(ve_model_path, map_location=torch.device('cpu'))['netG'])
        elif ve_model_type == 'Pix2PixModel':
            norm_layer = get_norm_layer(norm_type='instance')
            self.ve_net = GlobalGenerator(3, 1, 64, 4, 9, norm_layer)
            self.ve_net.load_state_dict(torch.load(ve_model_path, map_location=torch.device('cpu'))['netG'])
        self.device = device
        # vegan_model_save_path = Path(__file__).parent / 'networks/vegan/weights/model_GD_100000lp_0.233.ckpt'
        self.ve_net.to(device)
        self.ve_net.eval()

    def convert_img(self, imgs, img_paths, size=(512, 512)):
        time=datetime.datetime.now()
        dataset = DatasetForVeGan(imgs, img_paths, size)
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=self.batch_size, shuffle=False,
                                                 num_workers=0)
        out_imgs = []
        out_img_paths = []
        for i, (real_As, img_paths_, sizes,borders) in enumerate(dataloader):
            real_As = real_As.to(self.device)
            # with torch.no_grad():
            fake_Bs = self.ve_net(real_As)

            fake_Bs = fake_Bs.mul(255).add_(0.5).clamp_(0, 255).to('cpu', torch.uint8).numpy()[:, 0, :, :]
            for j, (size,border) in enumerate(zip(sizes,borders)):
                size = size.numpy()
                # size = (size[0].item(), size[1].item())
                fake_B = cv2.resize(fake_Bs[j], (size[1], size[0]))
                fake_B=cv2.copyMakeBorder(fake_B,int(border[0]),int(border[1]),int(border[2]),int(border[3]),cv2.BORDER_CONSTANT,0)
                out_imgs.append(fake_B)
                out_img_paths.append(img_paths_[j])
                # origin=cv2.resize(real_As[0].permute(1,2,0).cpu().numpy(),(size[1], size[0]))
                # cv2.imshow('origin',origin)
                # cv2.imshow('fakeb',fake_B)
                # cv2.waitKey()
            # cv2.waitKey()

        assert out_img_paths == img_paths
        return out_imgs, out_img_paths,datetime.datetime.now()-time
