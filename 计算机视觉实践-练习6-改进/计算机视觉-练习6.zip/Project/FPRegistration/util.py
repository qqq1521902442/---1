import os

import cv2
import numpy as np
from icecream import ic

from skimage import transform


def imread(image_path, flags=cv2.IMREAD_UNCHANGED):
    a = np.fromfile(image_path, dtype=np.uint8)
    original_image = cv2.imdecode(a, flags)
    return original_image


def imwrite(path, img, suffix='.bmp', mkdir=False):
    if mkdir and not os.path.exists(os.path.split(path)[0]):
        os.makedirs(os.path.split(path)[0])
    cv2.imencode(suffix, img)[1].tofile(path)


def get_default_config(config, path='config.yaml'):
    # f = open(path, encoding='utf-8')
    # config = yaml.safe_load(f)
    # f.close()
    config['nms_radius'] = 10
    config['keypoint_threshold'] = 0.05
    config['max_keypoints'] = 250
    config['sinkhorn_iterations'] = 40
    config['match_threshold'] = 0.02
    config['ve_batch_size'] = 2
    config['bj_batch_size'] = 2
    config['do_add_boundary'] = True
    config['ve_model_path'] = os.path.join(config['weights_dir'], config['ve_model_filename'])
    config['bj_model_path'] = os.path.join(config['weights_dir'], config['bj_model_filename'])
    config['superpoint_model_path'] = os.path.join(config['weights_dir'], config['superpoint_model_filename'])
    config['superglue_model_path'] = os.path.join(config['weights_dir'], config['superglue_model_filename'])
    return config

def get_histogram(img,x,y):
    bins = y - x
    hist, _ = np.histogram(img, bins, (x, y))  # 计算原始图像直方图
    # util.hist_equalize(hist,0.01)
    return hist

def color_histogram_match(img, img_ref):
    _, _, channel = img.shape
    imgOut = np.zeros_like(img)
    x = np.array([3, 3, 3])
    y = np.array([110, 160, 210])
    bins = y - x
    for i in range(channel):
        # print(i)
        histImg, _ = np.histogram(img[:, :, i], bins[i], (x[i], y[i]))  # 计算原始图像直方图
        histRef, _ = np.histogram(img_ref[:, :, i], bins[i], (x[i], y[i]))  # 计算匹配模板直方图
        cdfImg = np.cumsum(histImg) / np.sum(histImg)  # 计算原始图像累积分布函数 CDF
        cdfRef = np.cumsum(histRef) / np.sum(histRef)  # 计算匹配模板累积分布函数 CDF
        to = []
        for j in range(0, x[i]): to.append(j)
        for j in range(x[i], y[i]):
            tmp = abs(cdfImg[j - x[i]] - cdfRef)
            tmp = tmp.tolist()
            index = tmp.index(min(tmp))
            to.append(index)
        for j in range(y[i], 256): to.append(j)
        to = np.array(to, dtype=np.uint8)
        imgOut[:, :, i] = to[img[:, :, i]]
        # for j in range(x[i], y[i]):
        #     tmp = abs(cdfImg[j - x[i]] - cdfRef)
        #     tmp = tmp.tolist()
        #     index = tmp.index(min(tmp))  # find the smallest number in tmp, get the index of this number
        #     imgOut[:, :, i][img[:, :, i] == j] = index
    return imgOut


def img_resize(img, tar_size, flag=0):
    """
    图片小边缩放为指定大小(改成了把长缩放到指定大小）
    Args:
        img:
        tar_size: 如512
        flag: 0:h;1:w;2:较短边 缩放到与tar_size相等

    Returns:
        img
        scale
    """
    """
    
    :param img: 
    :param tar_size: 如512
    :return:
    """
    if tar_size == -1:
        return img
    if flag == 2:
        h, w = img.shape[0:2]
        s = 1.0 * tar_size / min(h, w)
        return cv2.resize(img, (0, 0), fx=s, fy=s)
    else:
        s = 1.0 * tar_size / img.shape[flag]
        return cv2.resize(img, (0, 0), fx=s, fy=s)


def calc_resize_scale(imgshape, tar_size, flag=0):
    if tar_size == -1:
        return 1
    if flag == 2:
        h, w = imgshape[0:2]
        s = 1.0 * tar_size / min(h, w)
        return s
    else:
        s = 1.0 * tar_size / imgshape[flag]
        return s


def merge_with_ImageWeightAndCoord(iwac, img, weight, method):
    sx, ex = iwac.left, iwac.left + iwac.shape_r
    sy, ey = iwac.top, iwac.top + iwac.shape_b

    if method == 'merge_max_weight':
        img_, weight_ = merge_max_weight(
            img[sy: ey, sx:ex, :], iwac.img,
            weight[sy: ey, sx:ex, :], iwac.weight)

        img[sy: ey, sx:ex, :] = img_
        weight[sy: ey, sx:ex, :] = weight_
        return img, weight


def hist_equalize(hist, proportion=0.03):
    threshold = (np.sum(hist) * proportion).astype(np.int64)
    count = 0
    for i in range(hist.shape[0]):
        if hist[i] > threshold:
            count += hist[i] - threshold
            hist[i] = threshold
    hist += count // hist.shape[0]
    return hist

def merge_with_IWAC_and_cdf(iwac, img, weight, tc3, tc1, method):
    sx, ex = iwac.left, iwac.left + iwac.shape_r
    sy, ey = iwac.top, iwac.top + iwac.shape_b

    if method == 'merge_max_weight':
        img_, weight_ = merge_max_weight(
            img[sy: ey, sx:ex, :], iwac.get_hist_matched_img(tc3, tc1),
            weight[sy: ey, sx:ex, :], iwac.weight)
        # img_, weight_ = merge_max_weight(
        #     img[sy: ey, sx:ex, :], iwac.get_CLAHE_img(),
        #     weight[sy: ey, sx:ex, :], iwac.weight)
        # img_, weight_ = merge_max_weight(
        #     img[sy: ey, sx:ex, :], iwac.img,
        #     weight[sy: ey, sx:ex, :], iwac.weight)

        img[sy: ey, sx:ex, :] = img_
        weight[sy: ey, sx:ex, :] = weight_
        return img, weight


def Color_burn(img_1, img_2):
    img = 1 - (1 - img_2) / (img_1 + 0.001)

    mask_1 = img < 0
    mask_2 = img > 1

    img = img * (1 - mask_1)
    img = img * (1 - mask_2) + mask_2

    '''
    row, col, channel = img.shape
    for i in range(row):
        for j in range(col):
            img[i, j, 0] = min(max(img[i, j, 0], 0), 1)
            img[i, j, 1] = min(max(img[i, j, 1], 0), 1)
            img[i, j, 2] = min(max(img[i, j, 2], 0), 1)
    '''

    return img


def Lighten(img_1, img_2):
    if max(len(img_1.shape), len(img_2.shape)) != min(len(img_1.shape), len(img_2.shape)):
        if len(img_1.shape) == 2:
            img_1 = cv2.cvtColor(img_1, cv2.COLOR_GRAY2BGR)
        else:
            img_2 = cv2.cvtColor(img_2, cv2.COLOR_GRAY2BGR)
    # img_1=cv2.cvtColor(img_1,cv2.COLOR_BGR2HLS)
    # img_2=cv2.cvtColor(img_2,cv2.COLOR_BGR2HLS)

    # img_1=np.where(img_1>150,150,img_1)
    # img_2=np.where(img_2>150,150,img_2)

    mask = img_1 > img_2
    # mask = (img > 0) & (img_2<10 & img_1 < 200)
    # mask = img > 0
    img = (img_1 * mask + img_2 * (1 - mask)).astype(np.uint8)
    # img=cv2.cvtColor(img,cv2.COLOR_HLS2BGR)
    return img


def Lighten_gray(img_1, img_2):
    if max(len(img_1.shape), len(img_2.shape)) != min(len(img_1.shape), len(img_2.shape)):
        if len(img_1.shape) == 2:
            img_1 = cv2.cvtColor(img_1, cv2.COLOR_GRAY2BGR)
        else:
            img_2 = cv2.cvtColor(img_2, cv2.COLOR_GRAY2BGR)
    # gray_1=cv2.cvtColor(img_1,cv2.COLOR_BGR2GRAY)
    # gray_2=cv2.cvtColor(img_2,cv2.COLOR_BGR2GRAY)
    gray_1 = img_1[:, :, 1]
    gray_2 = img_2[:, :, 1]

    mask = gray_1 > gray_2
    mask = np.expand_dims(mask, axis=2)
    mask = np.concatenate([mask, mask, mask], axis=2)
    # mask = (img > 0) & (img_2<10 & img_1 < 200)
    # mask = img > 0
    img = (img_1 * mask + img_2 * (1 - mask)).astype(np.uint8)
    # img=cv2.cvtColor(img,cv2.COLOR_HLS2BGR)
    return img


def Lighten_LAB(img_1, img_2):
    img1 = cv2.cvtColor(img_1, cv2.COLOR_BGR2LAB)
    img2 = cv2.cvtColor(img_2, cv2.COLOR_BGR2LAB)

    # img_1=np.where(img_1>150,150,img_1)
    # img_2=np.where(img_2>150,150,img_2)
    mask = np.array(img1[:, :, 2] > img2[:, :, 2], dtype=np.uint8)
    # mask = (img > 0) & (img_2<10 & img_1 < 200)
    # mask = img > 0
    if len(img_1.shape) > 2:
        mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    assert np.sum(mask[:, :, 0] > mask[:, :, 1]) == 0
    # img = (img_1 * mask + img_2 * (1 - mask)).astype(np.uint8)

    img = (img_1 * mask + img_2 * (1 - mask)).astype(np.uint8)
    # img=cv2.cvtColor(img,cv2.COLOR_HLS2BGR)
    return img


def merge_max_weight(img_1, img_2, weight_1, weight_2):
    if max(img_1.shape[2], img_2.shape[2]) != min(img_1.shape[2], img_2.shape[2]):
        if img_1.shape[2] == 1:
            img_1 = cv2.cvtColor(img_1, cv2.COLOR_GRAY2BGR)
        else:
            img_2 = cv2.cvtColor(img_2, cv2.COLOR_GRAY2BGR)
    # cv2.imshow('img_1',img_1)
    # cv2.imshow('img_2',img_2)
    # cv2.imshow('weight_1',weight_1)
    # cv2.imshow('weight_2',weight_2)
    # cv2.waitKey()
    # mask = weight_1 / (0.000001+weight_1 + weight_2)
    x = 6.
    mask = np.where(np.abs(weight_1.astype(np.int32) - weight_2) < x,
                    (weight_1.astype(np.int32) - weight_2 + x) / x / 2,
                    weight_1 > weight_2)[:, :, 0]
    # mask = weight_1>weight_2
    img = img_1.copy()
    for i in range(img_1.shape[2]):
        img[:, :, i] = (img_1[:, :, i] * mask + img_2[:, :, i] * (1 - mask)).astype(np.uint8)
    weight = np.where(weight_1 > weight_2, weight_1, weight_2)
    # weight = (weight_1 * mask + weight_2 * (1 - mask)).astype(np.uint8)
    # img=cv2.cvtColor(img,cv2.COLOR_HLS2BGR)
    return img, weight


def seamlessClone(img_1, img_2, mask_2):
    center = (img_1.shape[1] // 2, img_1.shape[0] // 2)
    # mask_2=np.zeros(img_2.shape,dtype=img_2.dtype)
    # mask_2=(1-mask_2)*255
    mask_2 = mask_2 * 255
    cv2.imshow('img_1', img_1)
    cv2.imshow('img_2', img_2)
    cv2.imshow('mask_2', mask_2)
    cv2.waitKey()
    # img_1=cv2.seamlessClone(img_2,img_1,mask_2,center,cv2.MIXED_CLONE)
    img_1 = cv2.textureFlattening(img_2, mask_2, img_1)
    return img_1


def Hard_mix(img_1, img_2):
    img_1 = img_1 / 255
    img_2 = img_2 / 255
    img = img_1 + img_2
    mask = img_1 + img_2 > 1
    img = img * (1 - mask) + mask
    img = img * mask
    return img * 255


def Screen(img_1, img_2):
    img = 1 - (1 - img_1 / 255) * (1 - img_2 / 255)

    return img * 255


def calc_scale_with_resize(img, mask, fit_size, tar_size):
    if tar_size != -1:
        img = img_resize(img, tar_size)
        mask = img_resize(mask, tar_size)
        scale = tar_size / fit_size
    else:
        h, w = img.shape[0:2]
        scale = min(h, w) / fit_size
    return img, mask, scale


def calc_scale(img, fit_size, tar_size):
    if tar_size != -1:
        scale = tar_size / fit_size
    else:
        h, w = img.shape[0:2]
        scale = min(h, w) / fit_size
    return scale


def calc_from(img, tar_size):
    if tar_size == -1:
        return transform.AffineTransform()
    else:
        h, w = img.shape[0:2]
        scale = min(h, w) / tar_size
        return transform.AffineTransform(scale=(scale, scale))


def remove_boundary_point(mask, last_data):
    kps = last_data['keypoints'][0].cpu().numpy().astype(np.int32)
    # if mask==None:
    #     mask = np.where(img <= 3, 1, 0)
    #     mask = np.array(mask, dtype=np.uint8)
    #     conv = np.ones((7, 7), dtype=np.uint8)
    # mask = scipy.signal.convolve(mask, conv, 'same', 'direct')
    valid = np.argwhere(mask[kps[:, 1], kps[:, 0]] == 0).reshape(-1)
    keypoints = [last_data['keypoints'][0][valid, :]]
    descriptors = [last_data['descriptors'][0][:, valid]]
    scores = [last_data['scores'][0][valid]]
    return {
        'keypoints': keypoints,
        'scores': scores,
        'descriptors': descriptors,
    }


def nms(last_data, scale):
    keypoints = last_data['keypoints'][0].cpu().numpy()
    descriptors = last_data['descriptors'][0].cpu().numpy()
    scores = last_data['scores'][0].cpu().numpy()
    ids = filt_point(keypoints, scores, scale)
    return {
        'keypoints': [last_data['keypoints'][0][ids, :]],
        'scores': [last_data['scores'][0][ids]],
        'descriptors': [last_data['descriptors'][0][:, ids]],
    }


def draw_kp_rm(mask, last_data, I):
    kps = last_data['keypoints'][0].cpu().numpy().astype(np.int32)
    valid = np.argwhere(mask[kps[:, 1], kps[:, 0]] == 0).reshape(-1)
    valid = set(valid)
    image = cv2.cvtColor(I, cv2.COLOR_GRAY2BGR)
    for i in range(kps.shape[0]):
        if i in valid:
            image = cv2.circle(image, (np.int32(kps[i, 0]), np.int32(kps[i, 1])), 5, (0, 0, 255), thickness=-1)
        else:
            image = cv2.circle(image, (np.int32(kps[i, 0]), np.int32(kps[i, 1])), 5, (0, 255, 0), thickness=-1)
    cv2.imshow('out', image)
    imwrite('outs/out.jpg', image, '.jpg')
    cv2.waitKey()


def check_transform(shape0, shape1, tform, config):
    ic(tform.shear)
    if np.abs(tform.shear) > config['max_shear']:
        message = 'tform.shear=' + str(tform.shear) + '>' + str(config['max_shear'])
        return False, message
    ic(np.max(tform.scale) / np.min(tform.scale))
    if np.max(tform.scale) / np.min(tform.scale) > config['max_scale_ratio']:
        message = 'np.max(tform.scale)/np.min(tform.scale)=' + str(
            np.max(tform.scale) / np.min(tform.scale)) + '>' + str(config['max_scale_ratio'])
        return False, message
    # print('tform.shear', tform.shear)
    # print('np.max(tform.scale)/np.min(tform.scale)', np.max(tform.scale) / np.min(tform.scale))
    mx = max(shape0[0], shape0[1]) * 2
    value = np.array([[0, 0], [0, shape1[0]], [shape1[1], 0], [shape1[1], shape1[0]]])
    value = tform.inverse(value)
    ic(np.max(value), np.min(value))
    if np.max(value) > mx or np.min(value) < -mx or np.isnan(np.min(value)):
        message = 'np.max(value) > mx or np.min(value) < -mx or np.isnan(np.min(value))'
        return False, message

    return True, ''


def try_remove(img, mask):
    rows, cols = img.shape[0], img.shape[1]
    src_cols = np.linspace(0, cols - 1, 20).astype(np.int32)
    src_rows = np.linspace(0, rows - 1, 10).astype(np.int32)
    src_rows, src_cols = np.meshgrid(src_rows, src_cols)
    kps = np.dstack([src_cols.flat, src_rows.flat])[0]
    cv2.imshow('before', draw_keypoints(img, kps))
    valid = np.argwhere(mask[kps[:, 0], kps[:, 1]] == 0).reshape(-1)
    kps = kps[valid]
    cv2.imshow('after', draw_keypoints(img, kps))
    cv2.waitKey()


def getMask(img, fit_size, threshold=3, confine=3, iterations=3):
    """
    获取图像黑边，用来去边缘点或者算重叠面积
    :param img:
    :return:  边缘处mask==1
    """
    img = img_resize(img, fit_size)
    mask = np.where(img <= threshold, 1, 0)
    # cv2.imshow('maskbefore',mask.astype(np.uint8)*255)
    mask = mask.astype(np.uint8)
    kernel = np.ones((confine, confine), dtype=np.uint8)
    mask = cv2.dilate(mask, kernel, iterations=iterations)
    # mask = cv2.morphologyEx(mask,cv2.MORPH_CLOSE, kernel, iterations=iterations)
    # cv2.imshow('maskafter',mask.astype(np.uint8)*255)
    # cv2.waitKey()
    return mask


def getMask_morphologyEx(img, fit_size, threshold=3, confine=5, iterations=3):
    """
    获取图像黑边，用来去边缘点或者算重叠面积
    :param img:
    :return:  边缘处mask==1
    """
    img = img_resize(img, fit_size)
    mask = np.where(img <= threshold, 1, 0)
    # cv2.imshow('maskbefore',mask.astype(np.uint8)*255)
    mask = mask.astype(np.uint8)
    kernel = np.ones((confine, confine), dtype=np.uint8)
    # mask = cv2.dilate(mask, kernel, iterations=iterations)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=iterations)
    # cv2.imshow('maskafter',mask.astype(np.uint8)*255)
    # cv2.waitKey()
    return mask


def filt_point(keypoints, scores, scale):
    '''
    删除距离过近的点, 返回保留的点的下标
    scale一般大于1, 也就是缩小尺寸,
    缩小尺寸后重合多余的点被删除.
    因此scale小于1无意义
    '''
    keypoints = keypoints / scale + 0.5
    keypoints = keypoints.astype(np.int64)
    N = keypoints.shape[0]
    # 为每一个坐标计算一个唯一的整数code, 如果坐标重复, code也必然重复, 减少去重的复杂度
    max_num = keypoints.max() + 1
    kpt_codes = keypoints[:, 0] * max_num + keypoints[:, 1]
    kpt_codes = np.reshape(kpt_codes, (N, 1))
    scores = np.reshape(scores, (N, 1))
    # 拼接置信度列
    kpt_codes = np.concatenate((kpt_codes, scores), axis=1)
    # 对每一个点标号, 拼接后, 每一个元素应该是[code, score, id]
    idx_ = np.arange(N).reshape(N, 1)
    kpt_codes = np.concatenate((kpt_codes, idx_), axis=1)

    l_ = kpt_codes.tolist()
    l_.sort(key=lambda s: (s[0], s[1]), reverse=True)

    code_set = set()
    ids = []
    for i in l_:
        if (i[0] in code_set):
            pass
        else:
            code_set.add(i[0])
            # 记录下标
            ids.append(int(i[2]))

    return ids


def filt_point_abandon(keypoints, scores, scale):
    '''删除距离过近的点, 返回保留的点的下标
    scale一般大于1, 也就是缩小尺寸,
    缩小尺寸后重合多余的点被删除.
    因此scale小于1无意义
    '''
    keypoints = keypoints / scale + 0.5
    keypoints = keypoints.astype(np.int64)
    N = keypoints.shape[0]
    scores = np.reshape(scores, (N, 1))
    # 拼接置信度列
    kpt_codes = np.concatenate((keypoints, scores), axis=1)
    # 对每一个点标号, 拼接后, 每一个元素应该是[code, score, id]
    idx_ = np.arange(N).reshape(N, 1)
    kpt_codes = np.concatenate((kpt_codes, idx_), axis=1)

    l_ = kpt_codes.tolist()
    l_.sort(key=lambda s: (s[0], s[1], s[2]), reverse=True)

    pre = [-1, -1]
    ids = []
    for i in l_:
        if (i[:2] == pre):
            pass
        else:
            pre = i[:2]
            # 记录下标
            ids.append(i[3])

    return ids


def draw_keypoints(img, kp, color=(255, 0, 0), radius=2, target_channel=-1):
    '''
        arguments: gray images
                kp1 is shape Nx2, N number of feature points, first point in horizontal direction
                '''
    image = np.copy(img)
    kp = np.array(kp[0])
    for i in range(kp.shape[0]):
        image = cv2.circle(image, (np.int32(kp[i, 0]), np.int32(kp[i, 1])), radius, color, thickness=-1)
    if target_channel == -1:
        return image
    out = np.copy(img)
    out[:, :, target_channel] = image[:, :, target_channel]

    return out


def draw_del_keypoints(img, kp, color=(255, 0, 0), radius=2, target_channel=-1):
    '''
        arguments: gray images
                kp1 is shape Nx2, N number of feature points, first point in horizontal direction
                '''
    image = np.copy(img)
    for i in range(len(kp)):
        image = cv2.circle(image, (np.int32(kp[i][0]), np.int32(kp[i][1])), radius, color, thickness=-1)
    if target_channel == -1:
        return image
    out = np.copy(img)
    out[:, :, target_channel] = image[:, :, target_channel]

    return out

# def draw_keypoints(img, kp, target_channel):
#     '''
#         arguments: gray images
#                 kp1 is shape Nx2, N number of feature points, first point in horizontal direction
#                 '''
#     image = np.zeros_like(img)
#     for i in range(kp.shape[0]):
#         image = cv2.circle(image, (np.int32(kp[i, 0]), np.int32(kp[i, 1])), 22, (255,255,255), thickness=-1)
#     out = np.copy(img)
#     out[:, :, target_channel] |= image[:,:,target_channel]
#     return out

def getLeftUpBorder_with_ski(tform):
    x = np.array([[0, 0]])
    return tform.inverse(x).astype(np.int)


def getLeftUpBorders_with_ski(tforms):
    x = np.array([[0, 0]])
    z = np.array([0, 0])
    for tform in tforms:
        if tform is None:
            continue
        y = tform.inverse(x)[0]
        z = np.where(y > z, y, z)
    return z


def getBorders_with_ski(imgs: list, tforms: list, shape=(0, 0)):
    """

    Args:
        imgs: 图像list
        tforms: 变换矩阵list
        shape: 初始的外界约束最小尺寸

    Returns:

    """
    # x = np.array([[0, 0], [0, shape[0]], [shape[1], 0], [shape[1], shape[0]]])
    left_up, right_down = np.array([0, 0]), np.array([shape[1], shape[0]])

    for i, data in enumerate(imgs):
        if tforms[i] is None:
            continue
        shape = imgs[i].shape[:2]
        x = np.array([[0, 0], [0, shape[0]], [shape[1], 0], [shape[1], shape[0]]])
        y = tforms[i].inverse(x)
        a = (np.min(y[:, 0]), np.min(y[:, 1]))
        left_up = np.where(a < left_up, a, left_up)
        b = (np.max(y[:, 0]), np.max(y[:, 1]))
        right_down = np.where(b > right_down, b, right_down)
    left_up = np.where(left_up < 0, -left_up, 0)
    right_down = (right_down + left_up)
    return np.array([left_up[1], left_up[0]]), np.array([right_down[1], right_down[0]])


def calc_border(tform, shape_self, shape=(0, 0)):
    """
    计算图像warp后的外接矩形坐标
    :param tform: 变换参数
    :param shape_self: 进行warp的图像shape
    :param shape: 人为决定的最小shape
    :return: left,top,right,bottom
    """
    left_top, right_bottom = np.array([0, 0]), np.array([shape[1], shape[0]])

    x = np.array([[0, 0], [0, shape_self[0]], [shape_self[1], 0], [shape_self[1], shape_self[0]]])
    y = tform.inverse(x)
    a = (np.min(y[:, 0]), np.min(y[:, 1]))
    left_top = a
    # left_top = np.where(a < left_top, a, left_top)
    b = (np.max(y[:, 0]), np.max(y[:, 1]))

    right_bottom = np.where(b > right_bottom, b, right_bottom)
    return int(left_top[0]), int(left_top[1]), int(right_bottom[0]), int(right_bottom[1])


def addLeftUpBorder(img, border):
    """
    左上角增加黑边
    :param img: shape=(a,b)
    :param border: (a,b)
    :return:
    """
    if len(img.shape) > 2:
        tmp = np.zeros((border[0] + img.shape[0], border[1] + img.shape[1], img.shape[2]), np.uint8)
    else:
        tmp = np.zeros((border[0] + img.shape[0], border[1] + img.shape[1]), np.uint8)
    tmp[border[0]:border[0] + img.shape[0], border[1]:border[1] + img.shape[1]] = img
    return tmp


def addBorder(img, border, left_up_border):
    if len(img.shape) > 2:
        tmp = np.zeros((border[0], border[1], img.shape[2]), np.uint8)
    else:
        tmp = np.zeros(border, np.uint8)
    tmp[left_up_border[0]:left_up_border[0] + img.shape[0], left_up_border[1]:left_up_border[1] + img.shape[1]] = img
    return tmp


def calc_tform_with_leftupBorder_abandoned(tform, left_up_border):
    x = np.array([[0, 0]])
    x = tform.__call__(x)
    x[0] = x[0] + left_up_border
    y = tform.inverse(x)[0]
    form = transform.AffineTransform(translation=(-y[1], -y[0]))
    return tform.__add__(form)


# def calc_tform_with_leftupBorder(tform,left_up_border):
#     x = np.array([[0, 0]])
#     x = tform.inverse(x)
#     x[0] = x[0] + [left_up_border[1],left_up_border[0]]
#     y = tform.__call__(x)[0]
#     form=skimage.transform.AffineTransform(translation=(-y[0],-y[1]))
#     return tform.__add__(form)

def calc_tform_with_leftupBorder(tform, to_right, to_bottom):
    """
    为tfrom增加一个平移操作，平移在tform变换之后
    :param tform: skimage.transform.GeometricTransform
    :param to_right: 向右移动to_right
    :param to_bottom: 向下移动to_bottom
    :return: 新的tfrom
    """
    # 由于skimage.transform.warp时应用的是tfrom.inverse()也就是逆，所以参数也要求逆，平移就是*-1
    form = transform.AffineTransform(translation=(-to_right, -to_bottom))
    return form.__add__(tform)


def addLeftUpBorder_cv_inverse(img, left_up_border, right_down_border, tform):
    x = np.array([[0, 0]])
    x = tform.__call__(x)
    x[0] = x[0] + left_up_border
    y = tform.inverse(x)[0]
    # print(left_up_border, y)
    # print(y)
    form = transform.AffineTransform(translation=(-y[1], -y[0]))
    return transform.warp(img, form, output_shape=right_down_border.astype(np.int32))

    # return cv2.copyMakeBorder(img, max(0, y[0]), 0, max(0, y[1]), 0, cv2.BORDER_CONSTANT)


def addBorder_cv(img, right_down_border, left_up_border, cval=0.):
    # x = left_up_border.astype(np.int32)
    # y = np.array([max(0, border[0] - img.shape[0] - left_up_border[0]),
    #               max(0, border[1] - img.shape[1] - left_up_border[1])]).astype(np.int)
    # return cv2.copyMakeBorder(img, x[0], y[0], x[1], y[1], cv2.BORDER_CONSTANT)
    y = left_up_border
    form = transform.AffineTransform(translation=(-y[1], -y[0]))
    return (transform.warp(img, form, output_shape=right_down_border.astype(np.int32), cval=cval,
                           preserve_range=True)).astype(np.uint8)


# def addLeftUpBorder_use_ski_affine(img1, img2,tform):
#     border = getLeftUpBorder_with_ski(tform)[0]
#     if border[0] > 0 or border[1]>0:
#         border=np.array((border[1],border[0]))
#         border = np.where(border > 0, border, 0)
#         img1 = addLeftUpBorder(img1, border)
#         img2 = addLeftUpBorder(img2, border)
#     return img1, img2

def calc_blackborder(img):
    if img.shape.__len__() > 2:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # img=np.where(img<50,img,0)
    # cv2.imshow('out',img)
    # cv2.waitKey()
    edges_y, edges_x = np.where(img > 3)  ##h, w
    bottom = min(edges_y)
    top = max(edges_y)

    left = min(edges_x)
    right = max(edges_x)
    return bottom, top, left, right


def calc_blackborder_with_mask(mask):
    """

    Args:
        mask: [h,w] 边缘处mask==1

    Returns:

    """
    # img=np.where(img<50,img,0)
    # cv2.imshow('out',img)
    # cv2.waitKey()

    edges_y, edges_x = np.where(mask == 0)  ##h, w
    bottom = min(edges_y)
    top = max(edges_y)

    left = min(edges_x)
    right = max(edges_x)
    return bottom, top, left, right


def calc_blackborder_with_connectedComponents(img):
    threshold, mask = cv2.threshold(img, 3, 1, cv2.THRESH_BINARY)
    # num_objects, labels = cv2.connectedComponents(mask)
    num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(mask, connectivity=8, ltype=None)
    stat_list = stats[1:, 4].tolist()
    index = stat_list.index(max(stat_list))
    # cv2.imshow('mask',mask*255)
    mask = np.where(labels == index + 1, 0, 1).astype(np.uint8)
    # cv2.imshow('mask_',mask*255)
    # cv2.waitKey()
    return stats[index + 1][:4], mask


# 并查集
def find_fa(x, fathers):
    if fathers[x] != x:
        fathers[x] = find_fa(fathers[x], fathers)
    return fathers[x]


def union_fa(x, y, fathers):
    # 将y的根节点设置为x的根
    fa_x = find_fa(x, fathers)
    fa_y = find_fa(y, fathers)
    if fa_x != fa_y:
        fathers[fa_y] = fa_x
