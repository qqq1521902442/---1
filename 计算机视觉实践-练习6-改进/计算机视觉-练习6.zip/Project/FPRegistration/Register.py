import copy
import datetime
import random
import networkx as nx
import cv2
import skimage
import torch
import time
import numpy as np
import threading
from PIL import Image
from queue import Queue
import matplotlib.cm as cm
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED, FIRST_COMPLETED
from FPRegistration import util
from FPRegistration.DataGroup import DataGroup
from FPRegistration.BJ.BJ import BJ
from FPRegistration.GMMRegistration.GMMreg import GMM
from FPRegistration.ImageGroup import ImageGroup, TransformMatrix
from FPRegistration.vegan.VeGan import VeGan
from FPRegistration.superglue.matching import Matching
from FPRegistration.superglue.utils import frame2tensor, make_matching_plot_fast
from FPRegistration.Task_list import get_task_info, bfs_registration_order
from skimage import transform
from skimage import measure
from icecream import ic

from FPRegistration.util import Lighten


class Register(object):
    def __init__(self, config, logger=None, do_debug=False):
        torch.set_grad_enabled(False)
        self.device = config['device']
        # self.vegan = VeGan(ve_model_path, ve_model_type, device, ve_gan_batch_size)
        self.model_vegan = VeGan(config['ve_model_path'], config['ve_model_type'], config['ve_batch_size'], self.device)
        self.model_bj = BJ(config['bj_model_path'], config['bj_model_type'], config['bj_batch_size'], self.device)
        self.logger = logger
        self.do_degug = do_debug

    @staticmethod
    def combine_cfp_ffa(CFPs, CFP_fitted, CFP_ids, FFAs, FFA_ids):
        imgs = []
        Is = []
        CFP_index = 0
        FFA_index = 0
        while CFP_index < len(CFP_ids):
            if FFA_index < len(FFA_ids):
                if CFP_ids[CFP_index] < FFA_ids[FFA_index]:
                    imgs.append(CFPs[CFP_index])
                    Is.append(CFP_fitted[CFP_index])
                    CFP_index += 1
                else:
                    imgs.append(FFAs[FFA_index])
                    Is.append(FFAs[FFA_index])
                    FFA_index += 1
            else:
                imgs.append(CFPs[CFP_index])
                Is.append(CFP_fitted[CFP_index])
                CFP_index += 1
        while FFA_index < len(FFA_ids):
            imgs.append(FFAs[FFA_index])
            Is.append(FFAs[FFA_index])
            FFA_index += 1
        return imgs, Is


class SuperglueReg(Register):
    def __init__(self, config, logger=None, do_debug=False):
        super(SuperglueReg, self).__init__(config=config, logger=logger, do_debug=do_debug)
        config_super = {
            'superpoint': {
                'nms_radius': config['nms_radius'],
                'keypoint_threshold': config['keypoint_threshold'],
                'max_keypoints': config['max_keypoints'],
                'superpoint_model_path': config['superpoint_model_path']
            },
            'superglue': {
                'weights': config['superglue_model_path'],
                'sinkhorn_iterations': config['sinkhorn_iterations'],
                'match_threshold': config['match_threshold'],
            }
        }
        self.keys = ['keypoints', 'scores', 'descriptors', 'imageshape']
        self.matching = Matching(config_super).eval().to(self.device)
        logger.info('SuperglueReg init')

    def point_fast_detect_all(self, device, img_group: ImageGroup, num, matching, change_flag, model_vegan, model_bj):

        # st_time = time.time()
        torch.set_grad_enabled(False)

        # ic('开始线程' + img_group.get_img_name())
        img_group.initial(change_flag, model_vegan, model_bj)
        Imask = img_group.Imask
        img_tensor = frame2tensor(img_group.I, device)
        # last_data = self.matching.superpoint_arr[num]({'image': img_tensor})
        # if num % 2 == 0:
        #     last_data = matching.superpoint0({'image': img_tensor})
        # else:
        #     last_data = matching.superpoint({'image': img_tensor})
        last_data = matching.superpoint({'image': img_tensor})
        last_data = util.remove_boundary_point(Imask, last_data)
        # last_data = util.nms(last_data, scale=7)
        # last_data = util.nms(last_data, scale=9)
        # last_data = util.nms(last_data, scale=10)

        last_data['imageshape'] = torch.tensor(img_tensor.shape)
        img_group.detected_data = last_data
        # print("thread cost_time: ", time.time() - st_time)

    def point_detect_all_thread_pool(self, dataGroup: DataGroup, change_flag):
        time_detec = datetime.datetime.now()
        if dataGroup.config['use_thread_pool']:
            thread_pool = ThreadPoolExecutor(max_workers=dataGroup.config['thread_pool_size'])  ## 几核 + 2
            results = [
                thread_pool.submit(SuperglueReg.point_fast_detect_all, None, self.device, img_group, idx, self.matching,
                                   change_flag, self.model_vegan, self.model_bj)
                for idx, img_group in enumerate(dataGroup.img_groups)]
            wait(results, return_when=ALL_COMPLETED)
            thread_pool.shutdown(wait=True)
        else:
            for idx, img_group in enumerate(dataGroup.img_groups):
                self.point_fast_detect_all(self.device, img_group, idx, self.matching, change_flag, self.model_vegan,
                                           self.model_bj)
        dataGroup.set_time_kp_detect(datetime.datetime.now() - time_detec)

    def point_detect_all_threads(self, dataGroup: DataGroup, change_flag):
        """
        用superpoint对所有图片检测特征点  并行
        """
        time = datetime.datetime.now()
        print("dataGroup img size : ", len(dataGroup.img_groups))
        img_que = Queue(len(dataGroup.img_groups))
        threadLock = threading.Lock()
        threads = []

        st_time = time.time()

        # s_t = time.time()
        # thread_pool = ThreadPoolExecutor(max_workers=4)  ## 几核 + 2
        # c = 0
        #
        # results = [ thread_pool.submit(SuperglueReg.point_fast_detect_all, None, self.device,img_group,idx,self.matching)
        #             for idx,img_group in enumerate(dataGroup.img_groups)]
        # wait(results, return_when=ALL_COMPLETED)
        # thread_pool.shutdown(wait=True)

        class MyThread(threading.Thread):
            def __init__(self, threadID, name, device, img_que, matching, change_flag, model_vegan, model_bj):
                super(MyThread, self).__init__()
                self.threadID = threadID
                self.device = device
                self.img_que = img_que
                self.matching = matching
                self.name = name
                self.exitFlag = 0
                self.change_flag = change_flag
                self.model_vegan = model_vegan
                self.model_bj = model_bj

            def run(self):
                torch.set_grad_enabled(False)
                while not self.exitFlag:

                    if not self.img_que.empty():
                        now_img = self.img_que.get()
                        now_img.initial(self.change_flag, self.model_vegan, self.model_bj)

                        Imask = now_img.Imask
                        img_tensor = frame2tensor(now_img.I, self.device)
                        if self.threadID == 0:
                            last_data = self.matching.superpoint0({'image': img_tensor})
                        else:
                            last_data = self.matching.superpoint({'image': img_tensor})
                        last_data = util.remove_boundary_point(Imask, last_data)
                        # last_data = util.nms(last_data,5)
                        last_data['imageshape'] = torch.tensor(img_tensor.shape)
                        now_img.detected_data = last_data
                        # c_t = time.time()-st_time
                        # print("self_thread {} end_time......{}".format(name, c_t))

        for img_group in dataGroup.img_groups:
            img_que.put(img_group)

        for i in range(min(len(dataGroup.img_groups), 9)):
            name = "Thread-%d" % i
            t = MyThread(i % 2, name, self.device, img_que, self.matching, change_flag, self.model_vegan, self.model_bj)
            t.start()
            threads.append(t)

        while not img_que.empty():
            pass

        for t in threads:
            t.exitFlag = 1

        [t.join() for t in threads]
        dataGroup.set_time_kp_detect(datetime.datetime.now() - time)

    def point_detect_all(self, dataGroup: DataGroup):
        """
        用superpoint对所有图片检测特征点
        """
        time = datetime.datetime.now()
        for img_group in dataGroup.img_groups:
            Imask = img_group.Imask
            img_tensor = frame2tensor(img_group.I, self.device)
            last_data = self.matching.superpoint({'image': img_tensor})
            last_data = util.remove_boundary_point(Imask, last_data)
            # last_data = util.nms(last_data, 1)
            last_data['imageshape'] = torch.tensor(img_tensor.shape)
            if self.do_degug:
                out = util.draw_keypoints(img_group.I, last_data['keypoints'])
                cv2.imshow('out' + str(img_group.id), out)
            img_group.detected_data = last_data
        dataGroup.set_time_kp_detect(datetime.datetime.now() - time)

    def match_thread(self, keys, data0, data1, matching, index_x=0, index_y=0, num=0, confidence_filter_rate=0.01):
        # c_t = time.time()
        torch.set_grad_enabled(False)

        data0 = {k + '0': data0[k] for k in keys}
        data1 = {k + '1': data1[k] for k in keys}
        kpts0 = data0['keypoints0'][0].cpu().numpy()
        kpts1 = data1['keypoints1'][0].cpu().numpy()
        # with torch.no_grad:
        pred = matching({**data0, **data1}, num % 2)
        matches = pred['matches0'][0].cpu().detach().numpy()
        confidence = pred['matching_scores0'][0].cpu().detach().numpy()
        max_conf = np.max(confidence) * confidence_filter_rate
        # valid = np.argwhere(matches > -1)
        valid = np.logical_and(matches > -1, confidence > max_conf)
        if (sum(valid) < 4):
            if num < 0:
                return np.array([]), np.array([]), np.array([])
            else:
                return index_x, index_y, 0
        kmc = np.transpose(
            np.append(np.append(np.transpose(kpts0, (1, 0)), matches), confidence).reshape(4, (kpts0.shape[0])), (1, 0))
        kmc = kmc[valid]

        mkpts0 = kmc[:, 0:2].astype(np.float32)
        mkpts1 = kpts1[kmc[:, 2].astype(np.uint8).reshape(-1)].astype(np.float32)
        conf = kmc[:, 3]
        ## <0: 分支线程需要返回的 >=0 :  完全图的边
        if num < 0:
            return mkpts0, mkpts1, conf
        else:
            return index_x, index_y, np.sum(conf > 0.1)
        # print("{} thread_cost_time: {}".format(num, time.time() - c_t))

    def match(self, data0, data1, confidence_filter_rate=0.1):
        data0 = {k + '0': data0[k] for k in self.keys}
        data1 = {k + '1': data1[k] for k in self.keys}
        kpts0 = data0['keypoints0'][0].cpu().numpy()
        kpts1 = data1['keypoints1'][0].cpu().numpy()
        # with torch.no_grad:
        pred = self.matching({**data0, **data1})
        matches = pred['matches0'][0].cpu().numpy()
        confidence = pred['matching_scores0'][0].cpu().numpy()
        max_conf = max(np.max(confidence) * confidence_filter_rate, 0.01)
        # valid = np.argwhere(matches > -1)
        valid = np.logical_and(matches > -1, confidence > max_conf)
        if (sum(valid) < 4):
            return np.array([]), np.array([]), np.array([])
        kmc = np.transpose(
            np.append(np.append(np.transpose(kpts0, (1, 0)), matches), confidence).reshape(4, (kpts0.shape[0])), (1, 0))
        kmc = kmc[valid]
        # kmc = list(kmc)
        # kmc = sorted(kmc, key=functools.cmp_to_key(self.cmp))
        # kmc = np.array(kmc[:len(kmc)//3])
        # if (sum(valid) > 9):
        #     mask = LPM_filter(kmc[:, 0:2], kpts1[kmc[:, 2].astype(np.uint8).reshape(-1)])
        #     if (sum(mask) > 4):
        #         kmc = kmc[mask]
        # return valid
        mkpts0 = kmc[:, 0:2].astype(np.float32)
        mkpts1 = kpts1[kmc[:, 2].astype(np.uint8).reshape(-1)].astype(np.float32)
        conf = kmc[:, 3]

        # self.show_matches(data0, data1, mkpts0, mkpts1, conf)
        return mkpts0, mkpts1, conf

    def calc_affine(self, data0, data1, mkpts0, mkpts1, conf):
        tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.AffineTransform, min_samples=5,
                                                 residual_threshold=0.25, max_trials=1000, stop_probability=0.99)
        mkpts0 = mkpts0[inliners]
        mkpts1 = mkpts1[inliners]
        color = cm.jet(conf.reshape(-1))
        img0 = (data0['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
        img1 = (data1['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
        if self.do_degug:
            make_matching_plot_fast(
                img0, img1, None, None, mkpts0, mkpts1, color, [],
                path=None, show_keypoints=False, opencv_display=True, small_text=[])

    def show_matches(self, data0, data1, mkpts0, mkpts1, conf):
        color = cm.jet(conf.reshape(-1))
        kpts0 = data0['keypoints0'][0].cpu().numpy()
        img0 = (data0['image0'][0][0].cpu().numpy() * 255).astype(np.uint8)
        kpts1 = data1['keypoints1'][0].cpu().numpy()
        img1 = (data1['image1'][0][0].cpu().numpy() * 255).astype(np.uint8)
        make_matching_plot_fast(
            img0, img1, kpts0, kpts1, mkpts0, mkpts1, color, text=[],
            path=None, show_keypoints=True, opencv_display=True, small_text=[])

    def select_master_img(self, dataGroup: DataGroup):
        img_num = len(dataGroup.img_groups)
        ids = np.arange(img_num)
        random.shuffle(ids)
        mx, id = 0, 0
        detected_datas = [img_group.detected_data for img_group in dataGroup.img_groups]
        for i in range(0, img_num // 2):
            mkpts0, mkpts1, conf = self.match(detected_datas[ids[i * 2]], detected_datas[ids[i * 2 + 1]],
                                              dataGroup.config['superGlue']['match_point_filter'])
            sum = np.sum(conf > 0.8)
            if sum > mx:
                id = i
                mx = sum
        return ids[id * 2]

    def merge_detected_data(self, data0, data1, top, left, newx, newy, shape, scale0, scale1):
        kp0 = copy.deepcopy(data0['keypoints'][0]) * scale0
        kp1 = (copy.deepcopy(data1['keypoints'][0]) * scale1).int()
        kp0[:, 0] += left
        kp0[:, 1] += top
        kp0 /= scale0
        # data0['keypoints'][0]=kp0

        index = (kp1[:, 0] + kp1[:, 1] * shape[1]).numpy()
        kp1[:, 0] = torch.tensor(newx[index])
        kp1[:, 1] = torch.tensor(newy[index])
        kp1 = kp1.float() / scale1
        data = {}
        data['keypoints'] = [torch.cat((kp0, kp1))]
        data['scores'] = [torch.cat((data0['scores'][0], data1['scores'][0]))]
        data['descriptors'] = [torch.cat((data0['descriptors'][0], data1['descriptors'][0]), dim=1)]
        idx = util.filt_point(data['keypoints'][0].cpu().numpy(), data['scores'][0].cpu().numpy(), 10)
        data['keypoints'][0] = data['keypoints'][0][idx, :]
        data['scores'][0] = data['scores'][0][idx]
        data['descriptors'][0] = data['descriptors'][0][:, idx]
        return data

    def merge_detected_data_affine(self, data0, data1, left_top_border, tform, scale0, scale1):
        kp0 = copy.deepcopy(data0['keypoints'][0]) * scale0
        kp1 = copy.deepcopy(data1['keypoints'][0]) * scale1
        kp0[:, 0] += left_top_border[1]
        kp0[:, 1] += left_top_border[0]
        kp0 /= scale0
        # data0['keypoints'][0]=kp0

        kp1 = torch.tensor(tform.inverse(kp1).astype(np.float32))
        kp1 = kp1 / scale1
        data = {}
        data['keypoints'] = [torch.cat((kp0, kp1))]
        data['scores'] = [torch.cat((data0['scores'][0], data1['scores'][0]))]
        data['descriptors'] = [torch.cat((data0['descriptors'][0], data1['descriptors'][0]), dim=1)]


        data00 = copy.deepcopy(data)
        idx = util.filt_point(data['keypoints'][0].cpu().numpy(), data['scores'][0].cpu().numpy(), 7)
        data['keypoints'][0] = data['keypoints'][0][idx, :]
        data['scores'][0] = data['scores'][0][idx]
        data['descriptors'][0] = data['descriptors'][0][:, idx]
        data11 = copy.deepcopy(data)

        idx = util.filt_point(data['keypoints'][0].cpu().numpy(), data['scores'][0].cpu().numpy(), 11)
        data['keypoints'][0] = data['keypoints'][0][idx, :]
        data['scores'][0] = data['scores'][0][idx]
        data['descriptors'][0] = data['descriptors'][0][:, idx]

        data22 = copy.deepcopy(data)

        idx = util.filt_point(data['keypoints'][0].cpu().numpy(), data['scores'][0].cpu().numpy(), 13)

        data['keypoints'][0] = data['keypoints'][0][idx, :]
        data['scores'][0] = data['scores'][0][idx]
        data['descriptors'][0] = data['descriptors'][0][:, idx]


        # idx = util.filt_point(data['keypoints'][0].cpu().numpy(), data['scores'][0].cpu().numpy(), 11)
        # data['keypoints'][0] = data['keypoints'][0][idx, :]
        # data['scores'][0] = data['scores'][0][idx]
        # data['descriptors'][0] = data['descriptors'][0][:, idx]
        # idx = util.filt_point(data['keypoints'][0].cpu().numpy(), data['scores'][0].cpu().numpy(), 13)
        # data['keypoints'][0] = data['keypoints'][0][idx, :]
        # data['scores'][0] = data['scores'][0][idx]
        # data['descriptors'][0] = data['descriptors'][0][:, idx]
        return data00, data11, data22, data

    def multithreading_graph(self, img_groups, use_thread_pool=True, max_workers=4):
        c = 0
        g = nx.Graph()
        """回调函数 线程执行完 加边"""

        def g_add_edge(fn):
            g.add_edge(fn.result()[0], fn.result()[1], weight=fn.result()[2])

        img_num = len(img_groups)
        # 完全图 线程
        if use_thread_pool:
            thread_pool = ThreadPoolExecutor(max_workers=max_workers)  ## 几核 + 2
            results = []
            for i in range(img_num):
                g.add_node(i)
                for j in range(i + 1, img_num):
                    result = thread_pool.submit(SuperglueReg.match_thread
                                                , None, self.keys, img_groups[i].detected_data,
                                                img_groups[j].detected_data,
                                                self.matching, i,
                                                j, c)
                    result.add_done_callback(g_add_edge)
                    results.append(result)
                    c += 1
            wait(results, return_when=ALL_COMPLETED)
        else:
            for i in range(img_num):
                g.add_node(i)
                for j in range(i + 1, img_num):
                    result = self.match_thread(self.keys, img_groups[i].detected_data, img_groups[j].detected_data,
                                               self.matching, i, j, c)
                    g.add_edge(result[0], result[1], weight=result[2])
                    c += 1

        return g, nx.maximum_spanning_tree(g)

    def montage(self, dataGroup: DataGroup):
        time_st = time.time()
        if dataGroup.img_groups.__len__() == 0:
            return False
        self.logger.info('montage' + dataGroup.config['task_id'])
        img_num = len(dataGroup.img_groups)
        ids = list(np.arange(img_num))
        img_groups = dataGroup.img_groups
        imgs = [img_group.img for img_group in img_groups]
        scales = [img_group.scale for img_group in img_groups]
        detected_datas = [img_group.detected_data for img_group in img_groups]
        tforms = [img_group.scale_tform for img_group in img_groups]

        # master_id = self.select_master_img(dataGroup)
        # ids.remove(master_id)
        # matched_ids = [master_id]
        # master_detected_data = detected_datas[master_id].copy()
        # output_shape = (imgs[master_id].shape[0] // tforms[master_id].scale[0], imgs[master_id].shape[1] // tforms[master_id].scale[1])
        # master_img = transform.warp(imgs[master_id], tforms[master_id],
        #                             output_shape=output_shape,
        #                             preserve_range=True).astype(np.uint8)
        # show_img = util.draw_keypoints(master_img, [master_detected_data['keypoints'][0].cpu().numpy()*scales[master_id]])
        # cv2.imshow('output', show_img)
        # cv2.waitKey()

        # '''normal single thread graph start'''
        # g = nx.Graph()
        # for i in range(img_num):
        #     g.add_node(i)
        #     for j in range(i+1, img_num):
        #         mkpts0, mkpts1, conf = self.match(detected_datas[i], detected_datas[j])
        #         match_num = np.sum(conf > 0.4)
        #         g.add_edge(i, j, weight=match_num)
        #

        '''multithreading graph start'''
        g, maximum_tree = self.multithreading_graph(img_groups, dataGroup.config['thread_pool_size'])

        """bfs order registration begin"""
        task_list = bfs_registration_order(g, maximum_tree)
        master_id = task_list[0]
        master_detected_data = detected_datas[master_id].copy()
        # print(imgs[master_id].shape[:2])

        master_img = transform.warp(imgs[master_id], tforms[master_id],
                                    output_shape=(imgs[master_id].shape[:2][0] // tforms[master_id].scale[0],
                                                  imgs[master_id].shape[:2][1] // tforms[master_id].scale[1]),
                                    preserve_range=True).astype(np.uint8)

        total_match_time = 0
        gmm_cost_time = 0
        t_t = time.time()

        for select_id in task_list:  ##逐图像配准
            if select_id == task_list[0]:
                continue

            select_mkpts0, select_mkpts1, select_conf = self.match(master_detected_data, detected_datas[select_id],
                                                                   dataGroup.config['superGlue']['match_point_filter'])
            if len(select_mkpts0) == 0:
                print("jump over ", select_id)
                continue
            select_mkpts0 *= scales[master_id]
            select_mkpts1 *= scales[select_id]

            inliners = np.ones(select_mkpts0.shape[0]) == 1

            GMMparam = dataGroup.config['GMM']
            gmm = GMM(tau=GMMparam['tau'], lamda=GMMparam['lamda'], eta=GMMparam['eta'], gamma=GMMparam['gamma'],
                      beta=GMMparam['beta'], maxiter=GMMparam['max_iteration'])
            selected_img = transform.warp(imgs[select_id], tforms[select_id],
                                          output_shape=(imgs[select_id].shape[:2][0] // tforms[select_id].scale[0]
                                                        , imgs[select_id].shape[:2][1] // tforms[select_id].scale[1]),
                                          preserve_range=True).astype(np.uint8)
            # s_t = time.time()
            # make_matching_plot_fast(master_img, selected_img,
            #                         master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id],
            #                         detected_datas[select_id]['keypoints'][0].cpu().numpy() * scales[select_id],
            #                         select_mkpts0, select_mkpts1, cm.jet(select_conf.reshape(-1)), text=[], path=None,
            #                         show_keypoints=True, opencv_display=True, small_text=[]) ## 0.012
            # print('make_matching_plot_fast time ----: ', time.time() - s_t)

            gmm.setImgAndKeypoints(selected_img, master_img, select_mkpts1, select_mkpts0, select_conf,
                                   inliners)
            s_t = time.time()
            print("------------ now  select_id ----------  : ", select_id)

            img_idx, base_img, img_mask, base_mask, top, left, newx, newy = gmm.do_registration(return_map=True)
            # s_t = time.time()
            gmm_cost_time += time.time() - s_t
            master_detected_data = self.merge_detected_data(master_detected_data, detected_datas[select_id], top, left,
                                                            newx, newy, selected_img.shape, scales[master_id],
                                                            scales[select_id])  ## 0.0019
            # print('make_matching_plot_fast time ----: ', time.time() - s_t)
            if not img_idx.any():
                print('GMM 配准错误')
                continue
            # cv2.imshow('output',img_idx)
            # s_t = time.time()

            master_img = util.Lighten(base_img, img_idx)
            show_img = util.draw_keypoints(master_img,
                                           [master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id]])
            img1 = util.draw_keypoints(selected_img,
                                       [detected_datas[select_id]['keypoints'][0].cpu().numpy() * scales[select_id]])
            img0 = util.draw_keypoints(transform.warp(imgs[master_id], tforms[master_id],
                                                      output_shape=(
                                                          imgs[master_id].shape[:2][0] // tforms[master_id].scale[0],
                                                          imgs[master_id].shape[:2][1] // tforms[master_id].scale[1],),
                                                      preserve_range=True).astype(np.uint8),
                                       [detected_datas[master_id]['keypoints'][0].cpu().numpy() * scales[master_id]])
            # print('draw_keypoints time ----: ', time.time() - s_t) 0.12
            # cv2.imshow('output', show_img)
            # cv2.imshow('img0', img0)
            # cv2.imshow('img1', img1)
            # cv2.waitKey()

            master_detected_data['image'] = torch.tensor([[cv2.resize(master_img, (
                    np.array((master_img.shape[:2])) // scales[master_id]).astype(np.int32))[:, :, 0]]])
        now = datetime.datetime.now()
        # cv2.imwrite('Project/res/' + now.strftime("%d_%H_%M_%S") + '.png', master_img)
        Image.fromarray(master_img).save("./res/mosaic_result.png")
        print("gmm_cost_time ----: ", gmm_cost_time)  # 9.65
        print("do registration time : ", time.time() - t_t)
        return
        """bfs order registration end"""

        center_node, task_list, task_similarity, task_num = get_task_info(g, maximum_tree)
        # ic(task_list)
        '''graph end'''

        """ final_output = []
        for i in range(0, img_num - 1):
            print('i=',i,ids)
            selected_mkpts0, selected_mkpts1, selected_conf = None, None, None
            mx, select_id = 5, -1
            for id in ids:
                mkpts0, mkpts1, conf = self.match(master_detected_data, detected_datas[id])
                # mkpts0, mkpts1, conf=mkpts0, mkpts1, conf
                if dataGroup.config['do_display'] and ids.__len__()<4:
                    img = transform.warp(imgs[id], tforms[id],
                                                  output_shape=imgs[id].shape[:2] // tforms[id].scale,
                                                  preserve_range=True).astype(np.uint8)
                    make_matching_plot_fast(master_img, img,
                                            master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id],
                                            detected_datas[id]['keypoints'][0].cpu().numpy() * scales[id],
                                            mkpts0*scales[id], mkpts1*scales[id], cm.jet(conf.reshape(-1)), text=[],
                                            path=None, show_keypoints=True, opencv_display=True, small_text=[])
                sum = np.sum(conf >0.5)
                if sum > mx:
                    select_id = id
                    mx = sum

                    selected_mkpts0, selected_mkpts1, selected_conf = mkpts0, mkpts1, conf

            if select_id == -1:
                break
            ic(mx)
            ids.remove(select_id)
            tform, selected_inliners = skimage.measure.ransac((selected_mkpts0, selected_mkpts1),
                                                                  skimage.transform.AffineTransform,
                                                                  min_samples=4,
                                                                  residual_threshold=14, max_trials=1000,
                                                                  stop_probability=0.5)
            selected_mkpts0 *= scales[master_id]
            selected_mkpts1 *= scales[select_id]
            # selected_inliners = np.ones(selected_mkpts0.shape[0]) == 1

            GMMparam = dataGroup.config['GMM']
            gmm = GMM(tau=GMMparam['tau'], lamda=GMMparam['lamda'], eta=GMMparam['eta'], gamma=GMMparam['gamma'],
                      beta=GMMparam['beta'], maxiter=GMMparam['max_iteration'])

            output_shape_ = (imgs[select_id].shape[0] // tforms[select_id].scale[0], imgs[select_id].shape[1] // tforms[select_id].scale[1])

            selected_img = transform.warp(imgs[select_id], tforms[select_id],
                                          output_shape=output_shape_,
                                          preserve_range=True).astype(np.uint8)
            if dataGroup.config['do_display']:
                make_matching_plot_fast(master_img, selected_img,
                                        master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id],
                                        detected_datas[select_id]['keypoints'][0].cpu().numpy() * scales[select_id],
                                        selected_mkpts0, selected_mkpts1, cm.jet(selected_conf.reshape(-1)), text=[], path=None,
                                        show_keypoints=True, opencv_display=True, small_text=[])
            gmm.setImgAndKeypoints(selected_img, master_img, selected_mkpts1, selected_mkpts0, selected_conf,
                                   selected_inliners)
            img_idx, base_img, img_mask, base_mask, top, left, newx, newy = gmm.do_registration(return_map=True)
            master_detected_data = self.merge_detected_data(master_detected_data, detected_datas[select_id], top, left,
                                                            newx, newy, selected_img.shape, scales[master_id],
                                                            scales[select_id])
            if not img_idx.any():
                print('GMM 配准错误')
                continue
            # cv2.imshow('output',img_idx)
            master_img = util.Lighten(base_img, img_idx)

            if dataGroup.config['do_display']:
                show_img = util.draw_keypoints(master_img,
                                               [master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id]])
                img1 = util.draw_keypoints(selected_img,
                                           [detected_datas[select_id]['keypoints'][0].cpu().numpy() * scales[select_id]])
                img0 = util.draw_keypoints(transform.warp(imgs[master_id], tforms[master_id],
                                                          output_shape=imgs[master_id].shape[:2] // tforms[master_id].scale,
                                                          preserve_range=True).astype(np.uint8),
                                           [detected_datas[master_id]['keypoints'][0].cpu().numpy() * scales[master_id]])
                # cv2.imshow('output', show_img)
                # cv2.imshow('img0', img0)
                # cv2.imshow('img1', img1)
                # cv2.waitKey()

            master_detected_data['image'] = torch.tensor([[cv2.resize(master_img, (
                    np.array((master_img.shape[:2])) // scales[master_id]).astype(np.int32))[:, :, 0]]])
        time_total=datetime.datetime.now()-time_total
        # cv2.waitKey()
        ic(time_total.total_seconds())
        cv2.imwrite('final.png',master_img)




            final_output = master_img
            # show_img = util.draw_keypoints(master_img,
            #                                [master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id]])
            # img1 = util.draw_keypoints(selected_img,
            #                            [detected_datas[select_id]['keypoints'][0].cpu().numpy() * scales[select_id]])
            output_shape_ = (imgs[master_id].shape[0] // tforms[master_id].scale[0], imgs[master_id].shape[1] // tforms[master_id].scale[1])
            # img0 = util.draw_keypoints(transform.warp(imgs[master_id], tforms[master_id],
            #                                           output_shape=output_shape_,
            #                                           preserve_range=True).astype(np.uint8),
            #                            [detected_datas[master_id]['keypoints'][0].cpu().numpy() * scales[master_id]])
            # cv2.imshow('output', show_img)
            # cv2.imshow('img0', img0)
            # cv2.imshow('img1', img1)
            # cv2.waitKey()

            master_detected_data['image'] = torch.tensor([[cv2.resize(master_img, (
                    np.array((master_img.shape[:2])) // scales[master_id]).astype(np.int32))[:, :, 0]]]) """
        '''task start'''
        local_outputs = []
        local_master_detected_datas = []
        # 第一个元素保存最大值
        tops = [0]
        lefts = [0]
        rights = [0]
        bottoms = [0]
        # print('task list:', task_list)
        '''local task start '''
        for task_id in range(task_num):
            local_task = task_list[task_id]
            # local_task首个元素为center_node, 也就是master_id, 跳过遍历
            local_output, local_master_detected_data, total_top, total_left, total_right, total_bottom = self.montage_from_list(
                local_task[1:], center_node, detected_datas, imgs, tforms, scales, dataGroup)
            tops.append(total_top)
            lefts.append(total_left)
            rights.append(total_right)
            bottoms.append(total_bottom)
            if total_top > tops[0]:
                tops[0] = total_top
            if total_bottom > bottoms[0]:
                bottoms[0] = total_bottom
            if total_left > lefts[0]:
                lefts[0] = total_left
            if total_right > rights[0]:
                rights[0] = total_right
            # 保存每一个分支task的结果
            now = datetime.datetime.now()
            cv2.imwrite('Project/res/part' + str(task_id) + '_' + now.strftime("%d_%H_%M_%S") + '.png', local_output)
            local_outputs.append(local_output)
            local_master_detected_datas.append(local_master_detected_data)
        '''local task end'''
        # 根据这些较大图的两两关系, 计算几张大图的拼接顺序, 关系紧密的优先匹配
        # '紧密度'task_similarity默认降序, 遍历即可
        # 每一个元素为一个列表, 其中第一个元素是两张图的similarity, 除了排序无意义, 第二个是一个容量为2的集合, 包含了两张图的id
        # l_ = len(task_similarity)
        # done_set = set()
        # final_montage_seq = []
        # for i in range(l_):
        #     if len(done_set) == task_num:
        #         break
        #     tasks = task_similarity[i][1]
        #     """ # 如果这两个分支和已经融合的分支没有交集, 就另外进行融合(当然要考虑空集)
        #     if done_set and not done_set.intersection(tasks):
        #         final_montage_seq.append(list(tasks)) """
        #     for id in tasks:
        #         if id not in done_set:
        #             final_montage_seq.append(id)
        #     done_set.union(tasks)

        # final_shape=[imgs[center_node].shape[0]+tops[0]+bottoms[0],imgs[center_node].shape[1]+lefts[0]+rights[0],3]
        # final_output = np.zeros(final_shape)
        final_output = None
        """ for i in range(0, task_num):
            # 此处没有写反, 这样是为了反向扩展, 让原来的中心图像回到中心, 从而对齐
            left, top = tops[i], lefts[i]
            bottom = 0
            right = 0
            if top < 0:
                bottom = -top
                top = 0
            if left < 0:
                right = -left
                left = 0
            img = local_outputs[i] """
        for i in range(task_num):
            img = local_outputs[i]
            top, bottom, left, right = tops[0] - tops[i + 1], bottoms[0] - bottoms[i + 1], lefts[0] - lefts[i + 1], \
                                       rights[0] - rights[i + 1]
            img = cv2.copyMakeBorder(img, top, bottom, left, right, borderType=cv2.BORDER_CONSTANT, value=[0, 0, 0])
            if i == 0:
                final_output = img
                continue
            # cv2.imshow('border', img)
            # cv2.waitKey()
            # cv2.destroyAllWindows()
            # cv2.imwrite('Project/res/test'+str(i)+'.png', img)
            final_output = Lighten(final_output, img)

        # for i in range(0, task_num):
        #     img = local_outputs[i]
        #     top = bottom = math.ceil((final_shape[0] - img.shape[0]) / 2)
        #     right = left = math.ceil((final_shape[1] - img.shape[1]) / 2)
        #     img = cv2.copyMakeBorder(img, top, bottom, left, right, borderType=cv2.BORDER_CONSTANT, value=[0, 0, 0])
        #     # cv2.imwrite('Project/res/test'+str(i)+'.png', img)
        #     final_output = Lighten(final_output, img)

        # final_output, final_master_detected_data = self.montage_from_list(final_montage_seq[1:], 0, local_master_detected_datas, local_outputs, tforms, scales, dataGroup)
        '''task end'''
        time_et = time()
        ic(time_et - time_st)
        # cv2.imshow('final', final_output)
        # cv2.waitKey()
        now = datetime.datetime.now()
        cv2.imwrite('Project/res/full' + now.strftime("%d_%H_%M_%S") + '.png', final_output)


    def merge_img_gmm(self, dataGroup, img_group0, img_group1, mkpts0, mkpts1, conf, inliners):

        GMMparam = dataGroup.config['GMM']
        gmm = GMM(tau=GMMparam['tau'], lamda=GMMparam['lamda'], eta=GMMparam['eta'], gamma=GMMparam['gamma'],
                  beta=GMMparam['beta'], maxiter=GMMparam['max_iteration'])

        gmm.setImgAndKeypoints(img_group1.img, img_group0.img, img_group1.weight, img_group0.weight, mkpts1, mkpts0,
                               conf, inliners)
        img_idx, base_img, img_weight, base_weight, base_mask, top, left, right, bottom, newx, newy = gmm.do_registration(
            return_map=True)
        img_group0.detected_data = self.merge_detected_data(img_group0.detected_data, img_group1.detected_data, top,
                                                            left,
                                                            newx, newy, img_group1.img.shape, img_group0.scale,
                                                            img_group1.scale)
        return img_idx, base_img, img_weight, base_weight

    # def merge_img_affine(self, tform, img_group0, img_group1):
    #
    #     left_up_border, right_down_border = util.calc_border(img_group1.img, tform, img_group0.img.shape[:2])
    #     tform = util.calc_tform_with_leftupBorder(tform, left_up_border)
    #     time_warp = datetime.datetime.now()
    #     img_idx = (
    #         skimage.transform.warp(img_group1.img, tform, output_shape=right_down_border.astype(np.int32),
    #                                preserve_range=True)).astype(np.uint8)
    #     img_mask = (skimage.transform.warp(img_group1.weight, tform, output_shape=right_down_border.astype(np.int32),
    #                                        preserve_range=True)).astype(np.uint8)
    #     base_img = util.addBorder(img_group0.img, right_down_border, left_up_border)
    #     base_weight = util.addBorder(img_group0.weight, right_down_border, left_up_border)
    #     time_warp = datetime.datetime.now() - time_warp
    #     ic(time_warp.total_seconds())
    #     img_group0.detected_data = self.merge_detected_data_affine(img_group0.detected_data,
    #                                                                img_group1.detected_data, left_up_border, tform,
    #                                                                img_group0.scale, img_group1.scale)
    #     return img_idx, base_img, img_mask, base_weight

    def montage_with_order(self, dataGroup: DataGroup, match_order=None):
        time_montage = datetime.datetime.now()
        if dataGroup.img_groups.__len__() == 0:
            return False
        self.logger.info('montage' + dataGroup.config['task_id'])
        img_num = len(dataGroup.img_groups)
        ids = list(np.arange(img_num))
        img_groups = copy.deepcopy(dataGroup.img_groups)
        # for img_group in img_groups:
        #     # img_group.img=np.where(img_group.mask==1,img_group.img,0)
        #     img_group.img = cv2.resize(img_group.img,
        #                                (img_group.img.shape[:2] // img_group.scale_tform.scale).astype(np.int32)[::-1])
        #     img_group.mask = cv2.resize(img_group.mask,
        #                                 np.array(img_group.img.shape[:2]).astype(np.int32)[::-1])
        # img_group.detected_data*=img_group.scale
        # master_id = self.select_master_img(dataGroup)
        time_order = datetime.datetime.now()
        if match_order is None:
            match_order = []
            g, maximum_tree = self.multithreading_graph(img_groups, dataGroup.config['thread_pool_size'])
            task_list = bfs_registration_order(g, maximum_tree)
            for i in range(1, len(task_list)):
                match_order.append((task_list[0], task_list[i]))

        dataGroup.task_list = task_list
        time_order = datetime.datetime.now() - time_order
        ic(time_order.total_seconds())
        fathers = [i for i in range(len(img_groups))]
        for pair in match_order:
            x, y = util.find_fa(pair[0], fathers), util.find_fa(pair[1], fathers)
            ic(x, y)
            img_group0 = img_groups[x]
            img_group1 = img_groups[y]
            # img = util.draw_keypoints(img_group0.I, img_group0.detected_data['keypoints'])
            # cv2.imshow('img', img)
            # cv2.waitKey()
            # img = util.draw_keypoints(img_group1.I, img_group1.detected_data['keypoints'])
            # cv2.imshow('img', img)
            # cv2.waitKey()
            mkpts0, mkpts1, conf = self.match(img_group0.detected_data, img_group1.detected_data,
                                              dataGroup.config['superGlue']['match_point_filter'])
            mkpts0 *= img_group0.scale
            mkpts1 *= img_group1.scale
            if (len(mkpts0) < 4):
                ic(x, y, len(mkpts0))
                continue
            if dataGroup.config['tar_size'] == -1:
                residual_threshold = img_group1.img.shape[0] / 25
            else:
                residual_threshold = dataGroup.config['tar_size'] / 25

            # BUG ValueError: `min_samples` must be in range (0, <number-of-samples>)
            tform, inliners = skimage.measure.ransac((mkpts0, mkpts1),
                                                     skimage.transform.AffineTransform,
                                                     min_samples=4,
                                                     residual_threshold=residual_threshold, max_trials=1000,
                                                     stop_probability=0.9)
            # img_idx=skimage.transform.warp(img_group1.img,)
            if dataGroup.config['do_display']:
                make_matching_plot_fast(img_group0.img, img_group1.img,
                                        img_group0.detected_data['keypoints'][0].cpu().numpy() * img_group0.scale,
                                        img_group1.detected_data['keypoints'][0].cpu().numpy() * img_group1.scale,
                                        mkpts0[inliners], mkpts1[inliners], cm.jet(conf[inliners].reshape(-1)), text=[],
                                        path=None, show_keypoints=True, opencv_display=True, small_text=[])
            time_merge = datetime.datetime.now()
            ic(x, y, np.sum(conf[inliners]), np.sum(inliners))
            if np.sum(conf[inliners]) > 40:
                img_idx, base_img, img_weight, base_weight = self.merge_img_gmm(dataGroup, img_group0, img_group1,
                                                                                mkpts0, mkpts1, conf,
                                                                                inliners)
            else:
                #flag, message = util.check_transform(img_group0.img.shape[:2], tform, dataGroup.config)
                #flag, message = util.check_transform(img_group0.img.shape[:2], tform)
                flag, message = util.check_transform((dataGroup.bottom, dataGroup.right), img_group1.img.shape, tform,
                                                     dataGroup.config)
                if not flag:
                    ic(x, y, message)
                    continue
                ic('affine')
                img_idx, base_img, img_weight, base_weight = self.merge_img_affine(tform, img_group0, img_group1)
            time_merge = datetime.datetime.now() - time_merge
            ic(time_merge.total_seconds())
            # cv2.imwrite('base.png', base_img)
            # cv2.imwrite('float.png', img_idx)
            img_group0.img = util.Lighten(base_img, img_idx)
            # img_group0.img,img_group0.weight = util.Lighten_weight(base_img, img_idx,base_weight,img_weight)
            # img_group0.img = util.seamlessClone(base_img, img_idx,mask)
            # detected_img=cv2.resize(img_group0.img, (
            #         np.array((img_group0.img.shape[:2])) // img_group0.scale).astype(np.int32))
            # if len(detected_img.shape)>2:
            #     detected_img=detected_img[:,:,0]
            # img_group0.detected_data['image'] = [torch.tensor(detected_img)]
            shape = np.array(img_group0.img.shape[:2]) / img_group0.scale

            img_group0.detected_data['imageshape'] = torch.tensor([0, 0, shape[0], shape[1]], dtype=torch.float32)

            util.union_fa(x, y, fathers)
        re = set()
        time_write = datetime.datetime.now()
        for i, img_group in enumerate(img_groups):
            fa = util.find_fa(i, fathers)
            if fa not in re:
                re.add(i)
                cv2.imwrite('final' + str(fa) + '.png', img_groups[fa].img)
        time_write = datetime.datetime.now() - time_write
        ic(time_write.total_seconds())
        dataGroup.set_time_match(datetime.datetime.now() - time_montage)

    def show_keypoint(self, img, detected_data, scale):
        show_img = util.draw_keypoints(img,
                                       [detected_data['keypoints'][0].cpu().numpy() * scale])
        cv2.imshow('show_img', show_img)
        cv2.waitKey()

    def montage_with_order_affine(self, dataGroup: DataGroup, task_list=None):
        if dataGroup.img_groups.__len__() == 0:
            return False
        self.logger.info('montage' + str(dataGroup.config['task_id']))
        img_groups = dataGroup.img_groups
        if task_list is None:
            time_order = datetime.datetime.now()
            g, maximum_tree = self.multithreading_graph(img_groups, dataGroup.config['use_thread_pool'],
                                                    dataGroup.config['thread_pool_size'])
            task_list = bfs_registration_order(g, maximum_tree)
            dataGroup.time_order = datetime.datetime.now() - time_order
        time_match = datetime.datetime.now()
        dataGroup.task_list = task_list
        dataGroup.master_id = task_list[0]
        img_group0 = img_groups[task_list[0]]
        img_group0.transform = TransformMatrix(transform.AffineTransform())
        dataGroup.bottom = img_group0.img.shape[0]
        dataGroup.right = img_group0.img.shape[1]

        debug_draw_image = True
        if debug_draw_image:
            img_group0.warped_img = img_group0.img
            if dataGroup.config['do_display']:
                detected_data = copy.deepcopy(img_group0.detected_data['keypoints'])
                detected_data[0] = detected_data[0] * img_group0.scale

                img = util.draw_keypoints(img_group0.img, detected_data, radius=10,color=(0,255,0)) #color=(128, 0, 128) 紫色 (0, 0, 255)) (0, 255, 0))
                # img = util.draw_keypoints(img_group0.img,
                #                           detected_data, color=(0, 0, 255), radius=10)  # color=(128, 0, 128) 紫色 (0, 0, 255)) (0, 255, 0))

                cv2.imshow('img0', img)
                #cv2.imshow('Imask0', img_group0.Imask * 255)
        match_flag = False
        data1 = None
        data2 = None
        data0 = None
        print(task_list)
        for i, id in enumerate(task_list):
            if i == 0:
                continue
            img_group1 = img_groups[id]
            if dataGroup.config['do_display']:

                if img_group0.warped_img is not None and data2 is not None:
                    detected_data = copy.deepcopy(img_group0.detected_data['keypoints'])
                    detected_data[0] = detected_data[0] * img_group0.scale


                    data2 = data2['keypoints']
                    data2[0] = data2[0] * img_group0.scale

                    data1 = data1['keypoints']
                    data1[0] = data1[0] * img_group0.scale

                    data0 = data0['keypoints']
                    data0[0] = data0[0] * img_group0.scale
                    #cv2.imshow('orgin_image', img_group0.warped_img)
                    img = util.draw_keypoints(img_group0.warped_img, data0, color=(255, 255, 255), radius=10,
                                              target_channel=-1)
                    #
                    # #cv2.imshow('orgin_dect_image', img2)
                    #
                    # img = util.draw_keypoints(img, data1, color=(0, 255, 0), radius=6, target_channel=-1)
                    #
                    # img = util.draw_keypoints(img, data2, color=(0, 0, 255), radius=6, target_channel=-1)
                    # #cv2.imshow('orgin_dect_image', img)
                    #
                    # img = util.draw_keypoints(img, detected_data, color=(255, 0, 0), radius=8, target_channel=-1)
                    # cv2.imshow('dect_image', img)
                    # cv2.imwrite(r"C:\Users\MAC\Desktop\data\temp.png", img)
                    kp = np.array(data0[0])
                    dp = np.array(detected_data[0])
                    del_col = []
                    for i in range(kp.shape[0]):
                        d0 = (np.int32(kp[i, 0]), np.int32(kp[i, 1]))
                        de = True
                        for j in range(dp.shape[0]):
                            p0 = (np.int32(dp[j, 0]), np.int32(dp[j, 1]))
                            if p0 == d0:
                                de = False
                                break
                        if de:
                            del_col.append(d0)



                    # img = util.draw_keypoints(img, data2, color=(0, 0, 255), radius=6) # (0, 255, 0) 绿色
                    img = util.draw_keypoints(img, detected_data, color=(0, 255, 0), radius=10, target_channel=-1)

                    img = util.draw_del_keypoints(img, del_col, color=(0, 0, 255), radius=10, target_channel=2)
                    #img = util.draw_keypoints(img, data0, color=(255, 0, 0), radius=10, target_channel=0) #红色

                    cv2.imwrite("nms_image.jpg", img)
                    cv2.imshow('merge_image', img)
                    cv2.waitKey(0)

                # img = util.draw_keypoints(img_group1.I, img_group1.detected_data['keypoints'])
                #cv2.imshow('img1', img)
                #cv2.imshow('Imask1', img_group1.Imask * 255)

            mkpts0, mkpts1, conf = self.match(img_group0.detected_data, img_group1.detected_data,
                                              dataGroup.config['superGlue']['match_point_filter'])
            mkpts0 *= img_group0.scale
            mkpts1 *= img_group1.scale
            if (len(mkpts0) <= 5):
                ic(id, len(mkpts0))
                continue

            residual_threshold = min(img_group1.img.shape[0], img_group1.img.shape[1]) / 50

            tform, inliners = skimage.measure.ransac((mkpts0, mkpts1),
                                                     skimage.transform.AffineTransform,
                                                     min_samples=5,
                                                     residual_threshold=residual_threshold, max_trials=500,
                                                     stop_probability=0.9)

            # img_idx=skimage.transform.warp(img_group1.img,)
            if ic.enabled:
                out = make_matching_plot_fast(img_group0.warped_img, img_group1.img,
                                              img_group0.detected_data['keypoints'][0].cpu().numpy() * img_group0.scale,
                                              img_group1.detected_data['keypoints'][0].cpu().numpy() * img_group1.scale,
                                              mkpts0[inliners], mkpts1[inliners], cm.jet(conf[inliners].reshape(-1)),
                                              text=[],
                                              path=None, show_keypoints=True,
                                              opencv_display=dataGroup.config['do_display'], small_text=[])
                util.imwrite('outs/match/' + datetime.datetime.now().strftime("%d_%H_%M_%S") + '.jpg', out, '.jpg')

            if np.sum(conf[inliners]) < 1:
                ic(id, np.sum(conf[inliners]))
                continue
            flag, message = util.check_transform((dataGroup.bottom, dataGroup.right), img_group1.img.shape, tform,
                                                 dataGroup.config)
            if not flag:
                ic(id, message)
                continue
            left, top, right, bottom = util.calc_border(tform, img_group1.img.shape,
                                                        (dataGroup.bottom, dataGroup.right))
            to_right = max(0, -left)
            to_bottom = max(0, -top)
            img_group1.to_right = img_group0.to_right
            img_group1.to_bottom = img_group0.to_bottom

            img_group1.transform = TransformMatrix(tform)
            tform_add_border = util.calc_tform_with_leftupBorder(tform, max(0, -left), max(0, -top))
            img_group0.to_right += to_right
            img_group0.to_bottom += to_bottom
            dataGroup.right = right + to_right
            dataGroup.bottom = bottom + to_bottom

            data0, data1, data2, img_group0.detected_data = self.merge_detected_data_affine(img_group0.detected_data,
                                                                       img_group1.detected_data, (to_bottom, to_right),
                                                                       tform_add_border,
                                                                       img_group0.scale, img_group1.scale)
            if dataGroup.config['do_display']:
                img_idx = (
                    skimage.transform.warp(img_group1.img, tform_add_border,
                                           output_shape=(int(dataGroup.bottom), int(dataGroup.right)),
                                           preserve_range=True)).astype(np.uint8)
                base_img = util.addBorder(img_group0.img, (int(dataGroup.bottom), int(dataGroup.right)),
                                          (img_group0.to_bottom, img_group0.to_right))

                show_img = util.Lighten(base_img, img_idx)
                img_group0.warped_img = show_img
                # cv2.imshow('show_img', show_img)
                # cv2.waitKey()
            # detected_img = cv2.resize(img_group0.img, (
            #         np.array((img_group0.img.shape[:2])) // img_group0.scale).astype(np.int32))
            # if len(detected_img.shape) > 2:
            #     detected_img = detected_img[:, :, 0]
            # img_group0.detected_data['image'] = torch.tensor([[detected_img]])
            shape = np.array([dataGroup.bottom, dataGroup.right]) / img_group0.scale
            img_group0.detected_data['imageshape'] = torch.tensor([0, 0, shape[0], shape[1]], dtype=torch.float32)
            match_flag = True
        dataGroup.time_match = datetime.datetime.now() - time_match
        return match_flag

    def match_with_master_new(self, id, dataGroup: DataGroup):
        time_st = datetime.datetime.now()
        if dataGroup.img_groups.__len__() == 0:
            return False
        self.logger.info('match_resize_before,master=' + dataGroup.img_groups[id].get_img_name())
        tforms = []

        imgs = [img_group.img for img_group in dataGroup.img_groups]
        scales = [img_group.scale for img_group in dataGroup.img_groups]
        detected_datas = [img_group.detected_data for img_group in dataGroup.img_groups]
        # scales = dataGroup.scales
        # detected_datas = dataGroup.detected_datas
        # img0 = self.imgs[id]
        for i in range(len(detected_datas)):
            if i == id:
                tforms.append(dataGroup.img_groups[i].scale_tform)
                continue
            mkpts0, mkpts1, conf = self.match(detected_datas[id], detected_datas[i],
                                              dataGroup.config['superGlue']['match_point_filter'])
            if self.do_degug:
                self.show_matches(detected_datas[id], detected_datas[i], mkpts0, mkpts1, conf)
            if mkpts0.shape[0] < 6:
                self.logger.info(
                    dataGroup.img_groups[id].get_img_name() + '与' + dataGroup.img_groups[
                        i].get_img_name() + '匹配点数不足')
                tforms.append(None)
                continue
            img1_shape = imgs[i].shape
            mkpts0 *= scales[id]
            mkpts1 *= scales[i]
            # tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.AffineTransform, min_samples=4,
            #                                          residual_threshold=2, max_trials=1000, stop_probability=0.99)
            # tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.ProjectiveTransform, min_samples=4,
            #                                          residual_threshold=2, max_trials=1000, stop_probability=0.99)
            inliners = np.ones(mkpts0.shape[0]) == 1
            tform = skimage.transform.AffineTransform()
            tform.estimate(mkpts0, mkpts1)
            # tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.PolynomialTransform, min_samples=4,
            #                                          residual_threshold=2, max_trials=1000, stop_probability=0.99)
            # inv_tform, inliners=skimage.measure.ransac((mkpts1, mkpts0), skimage.transform.PolynomialTransform, min_samples=4,
            #                                          residual_threshold=2, max_trials=1000, stop_probability=0.99)
            # tform = skimage.transform.PolynomialTransform()
            # tform.estimate(mkpts0, mkpts1,order=1)
            # inv_tform = skimage.transform.PolynomialTransform()
            # inv_tform.estimate(mkpts1, mkpts0,order=1 )
            # tform=MyPolynomialTransform(tform,inv_tform)
            # if self.do_degug:
            # img0=skimage.transform.warp(dataGroup.img_groups[id].img,dataGroup.img_groups[id].scale_tform,output_shape=(1024,1024),preserve_range=True)[:,:,0]
            # img1=skimage.transform.warp(dataGroup.img_groups[i].img,dataGroup.img_groups[i].scale_tform,output_shape=(1024,1024),preserve_range=True)[:,:,0]
            # color = cm.jet(conf.reshape(-1))
            # make_matching_plot_fast(
            #     img0, img1, [], [], mkpts0, mkpts1, color, text=[],
            #     path=None, show_keypoints=True, opencv_display=True, small_text=[])
            # self.show_matches(detected_datas[id], detected_datas[i], mkpts0 / scales[id], mkpts1 / scales[i], conf)
            # self.show_matches(detected_datas[id], detected_datas[i], mkpts0[inliners] / scales[id],
            #                   mkpts1[inliners] / scales[i], conf)
            flag, message = util.check_transform(img1_shape, tform, dataGroup.config)
            if tform is not None and flag == False:
                self.logger.info(
                    dataGroup.img_groups[id].get_img_name() + '与' + dataGroup.img_groups[
                        i].get_img_name() + '矩阵明显有误' + message)
                tform = None
            if tform is not None:
                tform = tform.__add__(dataGroup.img_groups[i].scale_tform)
            # tform=dataGroup.img_groups[i].scale_tform.__add__(tform)
            tforms.append(tform)
            # cv2.imshow(i.__str__(),skimage.transform.warp(imgs[i],tform,output_shape=(512,768),preserve_range=True).astype(np.uint8))
        # cv2.waitKey()
        if (tforms.count(None) == tforms.__len__() - 1):
            return False

        if dataGroup.config['do_add_boundary']:
            left_up_border, right_down_border = util.getBorders_with_ski(imgs, tforms, (0, 0))
        else:
            left_up_border = np.array((0, 0))
            right_down_border = np.array(imgs[id].shape[:2])
        assert np.min(left_up_border) >= 0 and np.min(right_down_border) >= 0
        # todo 检查是否有错误地tform漏掉没删，有的话说明util.check_transform有bug要修
        mx = max(imgs[id].shape[0], imgs[id].shape[1]) * 4
        if np.max(right_down_border) > mx:
            self.logger.warning('矩阵明显有误,且存在程序bug导致的检测遗漏,border=' + right_down_border.__str__())
            return False
        dataGroup.set_tforms(tforms)
        dataGroup.set_border(left_up_border, right_down_border)
        dataGroup.set_time_match(datetime.datetime.now() - time_st)

        return True

        # cv2.imshow('img',self.imgs[id])
        # self.imgs[id] = util.addBorder_cv(self.imgs[id], right_down_border, left_up_border)
        # cv2.imshow('img_',self.imgs[id])
        # cv2.imshow('mask',self.masks[id]*255)
        # self.masks[id] = util.addBorder_cv(self.masks[id], right_down_border, left_up_border, cval=1.)
        # cv2.imshow('mask_',self.masks[id]*255)
        # cv2.waitKey()

    # def match_with_master_resize_before(self, id, write_path=None, do_merge=False, do_add_boundary=True):
    #     self.logger.info('match_resize_before,master=' + os.path.basename(self.img_paths[id]))
    #     tforms = []
    #     self.imgs[id], self.masks[id], scale0 = util.calc_scale_with_resize(self.imgs[id], self.masks[id],
    #                                                                         self.fit_size, self.tar_size)
    #     # img0 = self.imgs[id]
    #     for i in range(len(self.detected_datas)):
    #         if i == id:
    #             tforms.append(None)
    #             continue
    #         mkpts0, mkpts1, conf = self.match(self.detected_datas[id], self.detected_datas[i])
    #         if self.do_display:
    #             color = cm.jet(conf.reshape(-1))
    #             a = (self.detected_datas[id]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #             b = (self.detected_datas[i]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #             kp0 = self.detected_datas[id]['keypoints'][0].cpu().numpy()
    #             kp1 = self.detected_datas[i]['keypoints'][0].cpu().numpy()
    #             out = make_matching_plot_fast(
    #                 a, b, kp0, kp1, mkpts0, mkpts1, color, [],
    #                 path=None, show_keypoints=True, opencv_display=self.do_display, small_text=[])
    #         if mkpts0.shape[0] < 6:
    #             self.logger.info(os.path.basename(self.img_paths[i]) + '匹配点数不足')
    #             tforms.append(None)
    #             continue
    #         self.imgs[i], self.masks[i], scale1 = util.calc_scale_with_resize(self.imgs[i], self.masks[i],
    #                                                                           self.fit_size, self.tar_size)
    #         img1_shape = self.imgs[i].shape
    #         mkpts0 *= scale0
    #         mkpts1 *= scale1
    #         tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.AffineTransform, min_samples=4,
    #                                                  residual_threshold=2, max_trials=1000, stop_probability=0.99)
    #         # tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.ProjectiveTransform, min_samples=4,
    #         #                                          residual_threshold=2, max_trials=1000, stop_probability=0.99)
    #         if self.do_display:
    #             mkpts0 /= scale0
    #             mkpts1 /= scale1
    #             color = cm.jet(conf.reshape(-1))
    #             a = (self.detected_datas[id]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #             b = (self.detected_datas[i]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #             kp0 = self.detected_datas[id]['keypoints'][0].cpu().numpy()
    #             kp1 = self.detected_datas[i]['keypoints'][0].cpu().numpy()
    #             out = make_matching_plot_fast(
    #                 a, b, kp0, kp1, mkpts0, mkpts1, color, [],
    #                 path=None, show_keypoints=True, opencv_display=self.do_display, small_text=[])
    #             mkpts0 = mkpts0[inliners]
    #             mkpts1 = mkpts1[inliners]
    #             out = make_matching_plot_fast(
    #                 a, b, kp0, kp1, mkpts0, mkpts1, color, [],
    #                 path=None, show_keypoints=True, opencv_display=self.do_display, small_text=[])
    #         # tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.PolynomialTransform, min_samples=4,
    #         #                                          residual_threshold=2, max_trials=1000, stop_probability=0.99)
    #
    #         if tform is None:
    #             tforms.append(tform)
    #             continue
    #         if not util.check_transform(img1_shape, tform):
    #             self.logger.info(os.path.basename(self.img_paths[i]) + '矩阵明显有误')
    #             tform = None
    #         tforms.append(tform)
    #     time_4 = datetime.datetime.now()
    #     if do_add_boundary:
    #         left_up_border, right_down_border = util.getBorders_with_ski(self.imgs, tforms, self.imgs[id].shape)
    #     else:
    #         left_up_border = np.array((0, 0))
    #         right_down_border = np.array(self.imgs[id].shape[:2])
    #     mx = max(self.imgs[id].shape[0], self.imgs[id].shape[1]) * 3
    #     if np.max(right_down_border) > mx:
    #         self.logger.warning('矩阵明显有误,且存在检测遗漏')
    #         return None, [], time_4, datetime.datetime.now()
    #     # cv2.imshow('img',self.imgs[id])
    #     self.imgs[id] = util.addBorder_cv(self.imgs[id], right_down_border, left_up_border)
    #     # cv2.imshow('img_',self.imgs[id])
    #     # cv2.imshow('mask',self.masks[id]*255)
    #     self.masks[id] = util.addBorder_cv(self.masks[id], right_down_border, left_up_border, cval=1.)
    #     # cv2.imshow('mask_',self.masks[id]*255)
    #     # cv2.waitKey()
    #     # todo display
    #     if self.do_display:
    #         cv2.imshow('img0', self.imgs[id])
    #     # todo 补全边框 & img warp
    #     outs = []
    #     flag = False
    #     for i in range(len(self.detected_datas)):
    #         if i == id:
    #             outs.append(self.imgs[id])
    #             continue
    #         if tforms[i] is None:
    #             outs.append(None)
    #             continue
    #         flag = True
    #         img1 = self.imgs[i]
    #         # out_ = (skimage.transform.warp(img1, tforms[i],
    #         #                                output_shape=right_down_border.astype(np.int32)) * 255).astype(np.uint8)
    #         # img_ = np.where((img_ < 10) & (out_ > 9), out_, img_)
    #         if np.max(left_up_border) > 0:
    #             # img1 = util.addLeftUpBorder_cv_inverse(img1, left_up_border, right_down_border, tforms[i])
    #             tforms[i] = util.calc_tform_with_leftupBorder(tforms[i], left_up_border)
    #         out = (skimage.transform.warp(img1, tforms[i],
    #                                       output_shape=right_down_border.astype(np.int32)) * 255).astype(np.uint8)
    #         outs.append(out)
    #
    #         if self.do_display:
    #             cv2.imshow('img1', img1)
    #             cv2.imshow('out' + i.__str__(), out)
    #             cv2.waitKey()
    #     time_5 = datetime.datetime.now()
    #     if not flag:
    #         return [], [], time_4, time_5
    #
    #     save_paths = []
    #     if do_merge:
    #         merge = self.merge_imgs(id, tforms, right_down_border, outs)
    #         if self.do_display:
    #             cv2.imshow('merge', merge / 255)
    #             cv2.waitKey()
    #         outs = []
    #         if write_path != None:
    #             save_path = os.path.join(os.path.join(write_path, 'merge.jpg'))
    #             util.imwrite(save_path, merge, '.jpg')
    #             save_paths.append(save_path)
    #     # todo write img
    #     self.tforms = tforms
    #     if write_path != None:
    #         # util.imwrite(os.path.join(os.path.join(write_path, 'all.jpg')), img, '.jpg')
    #         # util.imwrite(os.path.join(os.path.join(write_path, 'all_.jpg')), img_, '.jpg')
    #         for i, out in enumerate(outs):
    #             if out is None:
    #                 continue
    #             img_name = os.path.basename(self.img_paths[i])
    #             save_path = os.path.join(os.path.join(write_path, img_name))
    #             util.imwrite(save_path, out, os.path.splitext(img_name)[-1])
    #             save_paths.append(save_path)
    #     return outs, save_paths, time_4, time_5
    #
    # def match_with_master(self, id, write_path=None):
    #     tforms = []
    #     scale0 = util.calc_scale(self.imgs[id], self.fit_size, self.tar_size)
    #     tform0 = util.calc_from(self.imgs[id], self.tar_size)
    #     img0 = self.imgs[id]
    #     # img0=(self.detected_datas[id]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #     for i in range(len(self.detected_datas)):
    #         if i == id:
    #             tforms.append(tform0)
    #             continue
    #         # with torch.no_grad():
    #         mkpts0, mkpts1, conf = self.match(self.detected_datas[id], self.detected_datas[i])
    #         if self.do_display:
    #             color = cm.jet(conf.reshape(-1))
    #             a = (self.detected_datas[id]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #             b = (self.detected_datas[i]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #             out = make_matching_plot_fast(
    #                 a, b, None, None, mkpts0, mkpts1, color, [],
    #                 path=None, show_keypoints=False, opencv_display=self.do_display, small_text=[])
    #         if mkpts0.shape[0] < 7:
    #             print('num_', i + 1, '匹配点数不足')
    #             tforms.append(None)
    #             continue
    #         scale1 = util.calc_scale(self.imgs[i], self.fit_size, self.tar_size)
    #         tform1 = util.calc_from(self.imgs[i], self.tar_size)
    #         img1_shape = self.imgs[i].shape
    #         mkpts0 *= scale0
    #         mkpts1 *= scale1
    #         tform, inliners = skimage.measure.ransac((mkpts0, mkpts1), skimage.transform.AffineTransform, min_samples=4,
    #                                                  residual_threshold=2, max_trials=1000, stop_probability=0.99)
    #         if tform is None:
    #             tforms.append(tform)
    #             continue
    #         tform = tform.__add__(tform1)
    #         if not util.check_transform(img1_shape, tform):
    #             print('矩阵明显有误', i)
    #             # tform = None
    #         tforms.append(tform)
    #     time_4 = datetime.datetime.now()
    #     left_up_border, right_down_border = util.getBorders_with_ski(self.imgs, tforms, (0, 0))
    #     mx = max(img0.shape[0], img0.shape[1]) * 3
    #     # if np.max(right_down_border) > mx:
    #     #     print('矩阵明显有误,且存在检测遗漏')
    #     #     return None, time_4, datetime.datetime.now()
    #     # left_up_border = np.array((0, 0))
    #     # right_down_border = np.array(img0.shape[0:2] * 2)
    #     # print(left_up_border,right_down_border)
    #     # immm=util.addBorder(img0, right_down_border, left_up_border)
    #     # img0 = util.addBorder_cv(img0, right_down_border, left_up_border)
    #     # mask0 = util.addBorder_cv(mask0, right_down_border, left_up_border)
    #     outs = []
    #     flag = False
    #     if self.do_display:
    #         cv2.imshow('img0', img0)
    #     # if write_path != None:
    #     #     if not os.path.exists(write_path):
    #     #         os.makedirs(write_path)
    #     #     img_name = os.path.basename(self.img_paths[id])
    #     #     util.imwrite(os.path.join(os.path.join(write_path, img_name)), img0, os.path.splitext(img_name)[-1])
    #
    #     img = None
    #     img_ = None
    #     for i in range(len(self.detected_datas)):
    #         # if i == id:
    #         #     outs.append((skimage.transform.warp(img0,tforms[i],output_shape=right_down_border.astype(np.int32)) * 255).astype(np.uint8))
    #         #     continue
    #         if tforms[i] is None:
    #             outs.append(None)
    #             continue
    #         flag = True
    #         img1 = self.imgs[i]
    #         out_ = (skimage.transform.warp(img1, tforms[i],
    #                                        output_shape=right_down_border.astype(np.int32)) * 255).astype(np.uint8)
    #         if img_ is None:
    #             img_ = out_
    #         else:
    #             a = np.where((img_ < 10) & (out_ > 9), out_, img_)
    #             # b = np.where((img > 0) & (out > 0), out // 2 + img // 2, 0)
    #             img_ = a
    #         # img1=(self.detected_datas[i]['image'][0][0].cpu().numpy() * 255).astype(np.uint8)
    #         if np.max(left_up_border) > 0:
    #             # img1 = util.addLeftUpBorder_cv_inverse(img1, left_up_border, right_down_border, tforms[i])
    #             tforms[i] = util.calc_tform_with_leftupBorder(tforms[i], left_up_border)
    #         # img1 = util.addBorder(img1, right_down_border, left_up_border)
    #
    #         out = (skimage.transform.warp(img1, tforms[i],
    #                                       output_shape=right_down_border.astype(np.int32)) * 255).astype(np.uint8)
    #         outs.append(out)
    #         if img is None:
    #             img = out
    #         else:
    #             a = np.where((img < 10) & (out > 9), out, img)
    #             # b = np.where((img > 0) & (out > 0), out // 2 + img // 2, 0)
    #             img = a
    #         if self.do_display:
    #             cv2.imshow('img1', img1)
    #             cv2.imshow('out' + i.__str__(), out)
    #             cv2.waitKey()
    #     time_5 = datetime.datetime.now()
    #     if not flag:
    #         outs = []
    #     save_paths = []
    #     if write_path != None:
    #         util.imwrite(os.path.join(os.path.join(write_path, 'all.jpg')), img, '.jpg')
    #         util.imwrite(os.path.join(os.path.join(write_path, 'all_.jpg')), img_, '.jpg')
    #         for i, out in enumerate(outs):
    #             if out is None:
    #                 continue
    #             img_name = os.path.basename(self.img_paths[i])
    #             save_path = os.path.join(os.path.join(write_path, img_name))
    #             util.imwrite(save_path, out, os.path.splitext(img_name)[-1])
    #             save_paths.append(save_path)
    #     return outs, save_paths, time_4, time_5

    #
    # def match_mode(self, mode=0):
    #     if (mode == 0):

    # def registering(self, img_paths, master_img=-1, write_path=None, fit_size=None, tar_size=None):
    #     if fit_size is not None:
    #         self.fit_size = fit_size
    #     if tar_size is not None:
    #         self.tar_size = tar_size
    #     time_1 = datetime.datetime.now()
    #     self.set_img(img_paths)
    #
    #     time_2 = datetime.datetime.now()
    #     self.point_detect_all()
    #
    #     time_3 = datetime.datetime.now()
    #     if master_img == -1:
    #         outs, time_4, time_5 = self.match_with_master(0, write_path)
    #         if outs is None or len(outs) == 0:
    #             outs, time_4, time_5 = self.match_with_master(1, write_path)
    #     else:
    #         outs, time_4, time_5 = self.match_with_master(master_img, write_path)
    #     time_6 = datetime.datetime.now()
    #     return outs, (time_2 - time_1).total_seconds(), (time_3 - time_2).total_seconds(), (
    #             time_4 - time_3).total_seconds(), (time_5 - time_4).total_seconds(), (time_6 - time_5).total_seconds()
    #
    # def registering_resize_before(self, img_paths, master_img=-1, write_path=None, fit_size=None, tar_size=None,
    #                               do_merge=False, do_add_boundary=True):
    #
    #     if fit_size is not None:
    #         self.fit_size = fit_size
    #     if tar_size is not None:
    #         self.tar_size = tar_size
    #     time_1 = datetime.datetime.now()
    #     self.set_img(img_paths)
    #     # return [],datetime.datetime.now(),datetime.datetime.now(),datetime.datetime.now(),datetime.datetime.now(),datetime.datetime.now()
    #     time_2 = datetime.datetime.now()
    #     self.point_detect_all()
    #
    #     time_3 = datetime.datetime.now()
    #     if master_img == -1:
    #         outs, save_paths, time_4, time_5 = self.match_with_master_resize_before(0, write_path, do_merge,
    #                                                                                 do_add_boundary)
    #         if outs is None or len(outs) == 0:
    #             outs, save_paths, time_4, time_5 = self.match_with_master_resize_before(1, write_path, do_merge,
    #                                                                                     do_add_boundary)
    #     else:
    #         outs, save_paths, time_4, time_5 = self.match_with_master_resize_before(master_img, write_path, do_merge,
    #                                                                                 do_add_boundary)
    #     time_6 = datetime.datetime.now()
    #     return outs, save_paths, (time_2 - time_1).total_seconds(), (time_3 - time_2).total_seconds(), (
    #             time_4 - time_3).total_seconds(), (time_5 - time_4).total_seconds(), (time_6 - time_5).total_seconds()
    #
    def cmp(self, a, b):
        a = a[3]
        b = b[3]
        if a > b:
            return -1
        elif a < b:
            return 1
        else:
            return 0

    def match_with_master_test(self, dataGroup: DataGroup):
        time_st = datetime.datetime.now()
        if dataGroup.img_groups.__len__() == 0:
            return False, None
        self.logger.info('match_resize_before,master=' + dataGroup.img_groups[0].get_img_name())
        scales = [img_group.scale for img_group in dataGroup.img_groups]
        detected_datas = [img_group.detected_data for img_group in dataGroup.img_groups]
        mkpts0, mkpts1, conf = self.match(detected_datas[0], detected_datas[1],
                                          dataGroup.config['superGlue']['match_point_filter'])
        # out = make_matching_plot_fast(
        #     dataGroup.img_groups[0].I, dataGroup.img_groups[1].I, [], [], mkpts0, mkpts1, cm.jet(conf.reshape(-1)),
        #     text=[],
        #     path=None, show_keypoints=True, opencv_display=True, small_text=[])
        if mkpts0.shape[0] < 4:
            dataGroup.set_time_match(datetime.datetime.now() - time_st)
            return False, None, None, None

        mkpts0 *= scales[0]
        mkpts1 *= scales[1]
        tform = skimage.transform.AffineTransform()
        tform.estimate(mkpts0, mkpts1)
        dataGroup.set_time_match(datetime.datetime.now() - time_st)

        return True, tform, mkpts0, mkpts1

    # todo tforms, scales, dataGroup 可能会和local_task_list, master_id , detected_datas下标不统一,
    # todo 因此后续需要调整
    def montage_from_list(self, local_task_list, master_id, detected_datas, imgs, tforms, scales, dataGroup):
        '''使用列表中的拼接顺序进行拼接. 
            master id 为主图的下标, 同时主图也一般是拼接的第一张图
        '''
        master_detected_data = detected_datas[master_id].copy()
        output_shape = (
            imgs[master_id].shape[0] // tforms[master_id].scale[0],
            imgs[master_id].shape[1] // tforms[master_id].scale[1])
        master_img = transform.warp(imgs[master_id], tforms[master_id],
                                    output_shape=output_shape,
                                    preserve_range=True).astype(np.uint8)
        # local_task.pop(0)
        local_output = None
        local_master_detected_data = None
        total_top = 0
        total_left = 0
        total_bottom = 0
        total_right = 0
        for img_id in local_task_list:
            # if isinstance(img_id, list):
            #     local_output, local_master_detected_data = self.montage_from_list(
            #         local_task_list, img_id[0], detected_datas, imgs, tforms, scales, dataGroup)

            mkpts0, mkpts1, conf = self.match(master_detected_data, detected_datas[img_id],
                                              dataGroup.config['superGlue']['match_point_filter'])
            mkpts0 *= scales[master_id]
            mkpts1 *= scales[img_id]
            inliners = np.ones(mkpts0.shape[0]) == 1

            GMMparam = dataGroup.config['GMM']
            gmm = GMM(tau=GMMparam['tau'], lamda=GMMparam['lamda'], eta=GMMparam['eta'], gamma=GMMparam['gamma'],
                      beta=GMMparam['beta'], maxiter=GMMparam['max_iteration'])

            output_shape_ = (
                imgs[img_id].shape[0] // tforms[img_id].scale[0], imgs[img_id].shape[1] // tforms[img_id].scale[1])

            selected_img = transform.warp(imgs[img_id], tforms[img_id],
                                          output_shape=output_shape_,
                                          preserve_range=True).astype(np.uint8)
            # make_matching_plot_fast(master_img, selected_img,
            #                         master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id],
            #                         detected_datas[select_id]['keypoints'][0].cpu().numpy() * scales[select_id],
            #                         select_mkpts0, select_mkpts1, cm.jet(select_conf.reshape(-1)), text=[], path=None,
            #                         show_keypoints=True, opencv_display=True, small_text=[])
            gmm.setImgAndKeypoints(selected_img, master_img, mkpts1, mkpts0, conf, inliners)

            img_idx, base_img, img_mask, base_mask, top, left, right, bottom, newx, newy = gmm.do_registration(
                return_map=True)
            total_top += top
            total_bottom += bottom
            total_left += left
            total_right += right
            master_detected_data = self.merge_detected_data(master_detected_data, detected_datas[img_id], top, left,
                                                            newx, newy, selected_img.shape, scales[master_id],
                                                            scales[img_id])
            if not img_idx.any():
                print('GMM 配准错误')
                continue
            # cv2.imshow('output',img_idx)
            master_img = util.Lighten(base_img, img_idx)
            local_output = master_img
            local_master_detected_data = master_detected_data
            # show_img = util.draw_keypoints(master_img,
            #                                [master_detected_data['keypoints'][0].cpu().numpy() * scales[master_id]])
            # img1 = util.draw_keypoints(selected_img,
            #                            [detected_datas[select_id]['keypoints'][0].cpu().numpy() * scales[select_id]])
            output_shape_ = (imgs[master_id].shape[0] // tforms[master_id].scale[0],
                             imgs[master_id].shape[1] // tforms[master_id].scale[1])
            # img0 = util.draw_keypoints(transform.warp(imgs[master_id], tforms[master_id],
            #                                           output_shape=output_shape_,
            #                                           preserve_range=True).astype(np.uint8),
            #                            [detected_datas[master_id]['keypoints'][0].cpu().numpy() * scales[master_id]])
            # cv2.imshow('output', show_img)
            # cv2.imshow('img0', img0)
            # cv2.imshow('img1', img1)
            # cv2.waitKey()

            master_detected_data['image'] = torch.tensor([[cv2.resize(master_img, (
                    np.array((master_img.shape[:2])) // scales[master_id]).astype(np.int32))[:, :, 0]]])
        return local_output, local_master_detected_data, total_top, total_left, total_right, total_bottom
# if __name__ == '__main__':
#     img_dir = r'C:\Users\yjoker\AOneDrive\Dataset\配准\colorandffa'
#     # img_dir = r'C:\Users\yjoker\AOneDrive\Dataset\配准\ffaandffa'
#     # img_dir = r'C:\Users\yjoker\AOneDrive\Dataset\配准\Retinal-Images'
#     imgs = []
#     img_paths = []
#     for i, img_name in enumerate(os.listdir(img_dir)):
#         img_path = os.path.join(img_dir, img_name)
#         img = util.imread(img_path)
#         img_paths.append(img_path)
#         imgs.append(util.img_resize(img, 512))
#         if i == 1:
#             break
#     # vegan = VeGan(device='cuda:0', batch_size=2)
#     # vegan.convert_img(imgs, img_paths)
#     surperglue = SuperglueReg()
#     surperglue.set_img(img_paths)
#     datas = surperglue.point_detect_all()
#     # surperglue.show_point_all()
#     mkpts0, mkpts1, conf = surperglue.match(datas[0], datas[1])
#     # surperglue.show_matches(datas[0], datas[1], mkpts0, mkpts1, conf)
#     # surperglue.calc_affine(datas[0], datas[1], mkpts0, mkpts1, conf)
#     # surperglue.match_with_master(0)
#     # surperglue.registering(img_paths,tar_size=512,write_path=r'C:\Users\yjoker\AOneDrive\Dataset\配准\out\test')
#
