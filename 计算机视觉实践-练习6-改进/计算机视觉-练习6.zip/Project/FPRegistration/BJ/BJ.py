import datetime
import os

import cv2
import numpy as np
import torchvision
import torch
from natsort import natsorted

from FPRegistration import util
from FPRegistration.BJ.mobilenet import MobileNet
from FPRegistration.BJ.mobilenetv2 import MobileNetV2
from torch.utils.data.dataset import Dataset


class DatasetForBJ(Dataset):
    def __init__(self, imgs, img_paths, size):
        self.imgs = []
        for img in imgs:
            self.imgs.append(self.resize(img, size))
        self.img_paths = img_paths
        self.size = size

    def resize(self, img, s):
        c = min(s / img.shape[0], s / img.shape[1])
        img = cv2.resize(img, (int(c * img.shape[1]), int(c * img.shape[0])))
        shape = list(img.shape)
        shape[0] = s
        shape[1] = s
        f = np.zeros(shape, np.uint8)
        ax, ay = (s - img.shape[1]) // 2, (s - img.shape[0]) // 2
        f[ay:img.shape[0] + ay, ax:img.shape[1] + ax] = img
        return f

    def __getitem__(self, index):
        img = self.imgs[index]
        # cv2.imshow('img',img)
        # cv2.waitKey()
        img = torchvision.transforms.ToTensor()(img)
        return img, self.img_paths[index]

    def __len__(self):
        return len(self.img_paths)


class BJ():
    def __init__(self, bj_model_path, bj_model_type, batch_size=2, device='cpu'):
        self.batch_size = batch_size
        if (bj_model_type == 'mobilenetv2'):
            self.bj_net = MobileNetV2(1, 2)
        elif bj_model_type == 'mobilenet':
            self.bj_net = MobileNet(class_num=2)
        self.bj_net.load_state_dict(torch.load(bj_model_path, map_location='cpu'))
        self.device = device
        # vegan_model_save_path = Path(__file__).parent / 'networks/vegan/weights/model_GD_100000lp_0.233.ckpt'
        self.bj_net.to(self.device)
        self.bj_net.eval()

    def calc_osod(self, imgs, img_paths, size=256):
        time=datetime.datetime.now()
        dataset = DatasetForBJ(imgs, img_paths, size=size)
        dataloader = torch.utils.data.DataLoader(dataset, batch_size=self.batch_size, shuffle=False, num_workers=0)
        out_img_paths = []
        predictions = []
        outputs = []
        # torch.set_grad_enabled(False)
        for i, (imgs, img_paths_) in enumerate(dataloader):
            # print(i)
            imgs = imgs.to(self.device)
            # with torch.no_grad():
            output = self.bj_net(imgs)
            output = torch.softmax(output, dim=1)
            prediction = torch.max(output, dim=1)[1]
            outputs.extend(list(output[:, 1].cpu().numpy()))
            out_img_paths.extend(img_paths_)
            predictions.extend(list(prediction.cpu().numpy()))
            # cv2.waitKey()

        assert out_img_paths == list(img_paths)
        return outputs,datetime.datetime.now()-time


if __name__ == '__main__':
    torch.set_grad_enabled(False)
    # todo 测试
    # img_dir = r'C:\Users\yjoker\AOneDrive\Dataset\OSOD\all'
    # img_dir = r'C:\Users\yjoker\AOneDrive\Dataset\配准\colorandffa'
    img_dir = r'C:\Users\yjoker\AOneDrive\Dataset\OSOD\糖尿病CFPFFA公开\os'
    # img_dir = r'C:\Users\yjoker\AOneDrive\同步文件夹\桌面\os'
    imgs = []
    img_paths = []
    img_names = natsorted(os.listdir(img_dir))
    for img_name in img_names:
        img_path = os.path.join(img_dir, img_name)
        img_paths.append(img_path)
        imgs.append(util.imread(img_path, cv2.IMREAD_GRAYSCALE))

    bj = BJ(r'C:\Users\yjoker\AOneDrive\Project\registering\python\Project\weights\mobilenetv2_config5_0.pt',
            'mobilenetv2', device='cuda:0', batch_size=2)
    # time = datetime.datetime.now()
    outputs,time= bj.calc_osod(imgs, img_paths)
    # print((datetime.datetime.now() - time).total_seconds())
    for (img_path, output) in zip(img_paths, outputs):
        print(img_path, output)
