import networkx as nx
import numpy as np
# from icecream import ic
# import matplotlib.pyplot as plt
# import matplotlib
# matplotlib.use('TkAgg')
def sum_weights(G, node):
    '''返回和这个点相连的边的权重之和'''
    edges = nx.edges(G, node)
    res = 0
    for e in edges:
        res += G[e[0]][e[1]]['weight']
    return res

def get_center_node(G):
    nodes_and_degrees = nx.degree(G)
    max_degree = -1
    center_node = -1
    for node, degree in nodes_and_degrees:
        if degree == max_degree and center_node != -1:
            weight_sum = sum_weights(G, node)
            center_sum = sum_weights(G, center_node)
            if weight_sum > center_sum:
                center_node = node
                continue
        if degree > max_degree:
            max_degree = degree
            center_node = node
    return center_node

def get_task_similarity(complete_graph, task_list, i, j):
    '''传入一个完全图和规划好的拼接顺序, 计算两个局部拼接顺序之间的相似性'''
    # 第一个元素是center_node, 不用计算
    local_i = task_list[i]
    center_i = local_i.pop(0)
    num_i = len(local_i)
    local_j = task_list[j]
    center_j = local_j.pop(0)
    num_j = len(local_j)
    similarity = 0
    for ni in range(num_i):
        for nj in range(num_j):
            node_i = local_i[ni]
            node_j = local_j[nj]
            similarity += complete_graph[node_i][node_j]['weight']

    local_i.insert(0, center_i)
    local_j.insert(0, center_j)
    return similarity

# 根据边权最大 构造最大堆 进行bfs搜索
def bfs_registration_order(cg,g):
    # 中心点（起始点）
    source = get_center_node(g)
    import heapq
    #print(g.edges())
    #print(g.nodes())
    # Boolean 数组标记 每个点是否加入生成树中 True / False
    flag = [False for i in range(len(g.nodes()))]
    que = []
    task_list = []
    # 构造heapq 默认是构造最小堆，所以我们需要将边权取负数，进行转换 并且将起始点的权值设置为 -9999999
    heapq.heappush(que,(-9999999999,source))
    while len(que)!=0:
        # 取 候选边中的 最大边来更新生成树
        value,idx = heapq.heappop(que)
        # 将点加入生成树中
        flag[idx] = True
        task_list.append(idx)
        nxnodes = nx.all_neighbors(g,idx)
        for y in nxnodes:
            # 点 y 是否在生成树中
            if flag[y]==True:
                continue
            #print(cg[idx][y]['weight'])
            # 默认是构造最小堆，所以我们需要将边权取负数来达到维护最大堆的效果
            heapq.heappush(que,(-cg[idx][y]['weight'],y))
    return task_list


def get_task_info(complete_graph, maximum_tree):
    center_node = get_center_node(maximum_tree)
    task_list = []
    # for n in nx.neighbors(maximum_tree, center_node):
    #     task_list.append([n])
    #     task_id = task_list.__len__
    g_ = maximum_tree.copy()
    g_.remove_edges_from(maximum_tree.edges(center_node))
    g_.remove_node(center_node)
    components = nx.connected_components(g_)
    center_neighbors = set(nx.neighbors(maximum_tree, center_node))
    # nx.draw(G=maximum_tree, with_labels=True, pos=nx.spring_layout(maximum_tree), node_color='r', node_size=1000, width=5)
    # plt.show()
    # ic(center_neighbors)
    for nodes in components:
        graph = nx.Graph(maximum_tree.subgraph(nodes))
        graph.add_node(center_node)
        graph.add_edge(center_node, nodes.intersection(center_neighbors).pop())
        local_task = list(nx.dfs_preorder_nodes(graph, source=center_node))
        task_list.append(local_task)
        # nx.draw(G=graph, with_labels=True, pos=nx.spring_layout(graph), node_color='r', node_size=1000, width=5)
        # plt.show()

    task_num = len(task_list)
    task_similarity = []
    for i in range(task_num):
        for j in range(i+1, task_num):
            similarity = get_task_similarity(complete_graph, task_list, i, j)
            task_similarity.append([similarity, {i,j}])
    task_similarity.sort(key=lambda x : x[0], reverse=True)
    return center_node, task_list, task_similarity, task_num
