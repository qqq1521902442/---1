import copy
import datetime
import os

import cv2
import numpy as np
import skimage
import torch
from icecream import ic

from FPRegistration import util


class TransformMatrix:
    def __init__(self, tfrom):
        self.tform = tfrom

    def warp_img(self, left, top, right, bottom, img):
        tform = util.calc_tform_with_leftupBorder(self.tform, left, top)
        return (skimage.transform.warp(img, tform, output_shape=(int(bottom), int(right)), preserve_range=True)).astype(
            np.uint8)

    def warp_img_remove_border(self, left, top, img):
        tform = util.calc_tform_with_leftupBorder(self.tform, left, top)
        left_, top_, right_, bottom_ = util.calc_border(tform, img.shape)
        assert min(left_, top_, right_, bottom_) >= 0
        tform = util.calc_tform_with_leftupBorder(tform, -left_, -top_)
        # ic(util.calc_border(tform, img.shape))
        shape_r = right_ - left_
        shape_b = bottom_ - top_
        return (skimage.transform.warp(img, tform, output_shape=(int(shape_b), int(shape_r)),
                                       preserve_range=True)).astype(
            np.uint8), left_, top_, shape_r, shape_b


class TransformMap:
    def __init__(self, newx, newy, originaly, originalx):
        self.newx = newx
        self.newy = newy
        self.originalx = originalx
        self.originaly = originaly

    def warp_img(self, left, top, right, bottom, img):
        dst = np.zeros((right, bottom)).astype('uint8')
        dst[self.newy + top, self.newx + left] = img[self.originaly, self.originalx]


class ImageWeightAndCoord:
    def __init__(self, img, weight, left, top, shape_r, shape_b):
        self.img = img
        self.weight = weight
        self.left = left
        self.top = top
        self.shape_r = shape_r
        self.shape_b = shape_b
        self.hist_list = None  # 图像的直方图
        self.hist_matched_img = None

    def get_output(self, right, bottom, flag=0):
        border_r = right - self.shape_r - self.left
        border_b = bottom - self.shape_b - self.top
        if flag == 0:
            img = cv2.copyMakeBorder(self.img, self.top, border_b, self.left, border_r, borderType=cv2.BORDER_CONSTANT)
            # weight = cv2.copyMakeBorder(self.weight, self.top, border_b, self.left, border_r,
            #                             borderType=cv2.BORDER_CONSTANT)
            if len(img.shape) == 2:
                img = np.expand_dims(img, axis=2)
            return img
        elif flag == 1:
            weight = cv2.copyMakeBorder(self.weight, self.top, border_b, self.left, border_r,
                                        borderType=cv2.BORDER_CONSTANT).expand_dim(axis=2)
            if len(weight.shape) == 2:
                weight = np.expand_dims(weight, axis=2)
            return weight
        else:
            img = cv2.copyMakeBorder(self.img, self.top, border_b, self.left, border_r, borderType=cv2.BORDER_CONSTANT)
            weight = cv2.copyMakeBorder(self.weight, self.top, border_b, self.left, border_r,
                                        borderType=cv2.BORDER_CONSTANT)
            if len(img.shape) == 2:
                img = np.expand_dims(img, axis=2)
            if len(weight.shape) == 2:
                weight = np.expand_dims(weight, axis=2)
            return img, weight

    def get_histogram(self):
        _, _, channel = self.img.shape
        if channel == 3:
            x = np.array([3, 3, 3])
            y = np.array([110, 160, 220])
            bins = y - x
        else:
            x = np.array([3])
            y = np.array([210])
            bins = y - x
        if self.hist_list is None:
            self.hist_list = []
            for i in range(channel):
                hist, _ = np.histogram(self.img[:, :, i], bins[i], (x[i], y[i]))  # 计算原始图像直方图
                self.hist_list.append(hist)
        return x,y,self.hist_list

    def get_hist_matched_img(self, tc3, tc1):
        if self.hist_matched_img is None:
            _, _, channel = self.img.shape
            self.hist_matched_img = np.zeros_like(self.img)
            if channel == 3:
                x, y, hist = self.get_histogram()
                for i in range(channel):
                    cdf_img = np.cumsum(hist[i]) / np.sum(hist[i])
                    cdf_ref = tc3[i]
                    to = []
                    for j in range(0, x[i]): to.append(j)
                    for j in range(x[i], y[i]):
                        tmp = abs(cdf_img[j - x[i]] - cdf_ref)
                        tmp = tmp.tolist()
                        index = tmp.index(min(tmp)) + x[i]
                        to.append(index)
                    for j in range(y[i], 256): to.append(j)
                    to = np.array(to, dtype=np.uint8)
                    self.hist_matched_img[:, :, i] = to[self.img[:, :, i]]
            else:
                x, y, hist = self.get_histogram()
                # hist = [util.hist_equalize(copy.deepcopy(hist[0]), 0.025)]
                cdf_img = np.cumsum(hist) / np.sum(hist)
                cdf_ref = tc1[0]
                to = []
                for j in range(0, x[0]): to.append(j)
                for j in range(x[0], y[0]):
                    tmp = abs(cdf_img[j - x[0]] - cdf_ref)
                    tmp = tmp.tolist()
                    index = tmp.index(min(tmp)) + x[0]
                    to.append(index)
                for j in range(y[0], 256): to.append(j)
                to = np.array(to, dtype=np.uint8)
                self.hist_matched_img[:, :, 0] = to[self.img[:, :, 0]]

        # cv2.imshow('origin', self.img)
        # cv2.imshow('out', self.hist_matched_img)
        # cv2.waitKey()
        return self.hist_matched_img

    def get_CLAHE_img(self):
        b, g, r = cv2.split(self.img)
        clahe = cv2.createCLAHE(clipLimit=0.2, tileGridSize=(4, 4))
        b = clahe.apply(b)
        g = clahe.apply(g)
        r = clahe.apply(r)
        image = cv2.merge([b, g, r])
        return image


class ImageGroup:
    weight_template = None

    # weight_template = (np.power(weight_template / float(np.max(weight_template)), 0.75) * 255).astype(np.uint8)
    # img_ref = util.imread('weights/histogram_ref.jpg')

    def __init__(self, id, img_path, config):
        self.id = id
        self.img_path = img_path
        self.img = util.imread(self.img_path, cv2.IMREAD_UNCHANGED)
        self.mask = None
        if self.get_channel() == 3:
            if np.sum(self.img[:, :, 0] != self.img[:, :, 1]) > 0.10 * self.img.shape[0] * self.img.shape[1]:
                self.is_CFP = True
            else:
                self.img = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
        # self.mask = None  #
        self.weight = None
        self.I = None  # fit_size img
        self.Imask = None  # fit_size 边缘mask=1
        self.scale = None  # img.shape[0] / self.config['tar_size']
        self.detected_data = None
        self.is_OS = None
        self.warped_img = None
        self.warped_mask = None
        self.img_name = None
        self.scale_tform = None
        self.transform = None
        self.config = config
        self.is_CFP = None
        # 对于基准图to_right,to_bottom表示的是基准图需要向右向下移动的像素大小
        # 对于其他图表示tfrom中已经包含了的右移和下移的像素，【基准图的to_right,to_bottom-其他图的to_right,to_bottom】表示需要补充的移动像素
        self.to_right = 0
        self.to_bottom = 0
        self.iwac = None
        self.initialized = False

    def initial(self, change_flag, model_vegan, model_bj):
        if self.initialized:
            return
        self.initialized = True
        # self.img = (np.power(self.img / float(np.max(self.img)), 0.95) * 255).astype(np.uint8)
        gray_img = self.remove_boundary()

        is_OSs, time_bj = model_bj.calc_osod([gray_img], [self.img_path], self.config['bj_size'])
        self.is_OS = is_OSs[0]
        if change_flag and self.get_is_CFP():
            fitted_imgs, paths, time_vegan = model_vegan.convert_img([self.img], [self.img_path])
            gray_img = fitted_imgs[0]
        self.I = util.img_resize(gray_img, self.config['fit_size'])
        h, w = self.I.shape[:2]
        # cv2.imshow(self.get_img_name(), self.I)
        # cv2.waitKey()
        self.Imask = cv2.resize(self.mask, (w, h))
        kernel = np.ones((3, 3), dtype=np.uint8)
        self.Imask = cv2.dilate(self.Imask, kernel, iterations=3)
        if self.config['tar_size'] == -1:
            self.scale = self.img.shape[0] / self.config['fit_size']
        else:
            self.scale = self.config['tar_size'] / self.config['fit_size']
        # self.right_down_border = np.array(self.img.shape[:2], dtype=np.int32)
        # img = cv2.cvtColor(self.img, cv2.COLOR_BGR2LAB)
        # img[:, :, 0] = np.where(img[:, :, 0] > 50, 50,img[:, :, 0])
        # self.img = cv2.cvtColor(img, cv2.COLOR_LAB2BGR)

    def remove_boundary_abandoned(self):
        if self.img.shape.__len__() > 2:
            gray_img = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
            # gray_img = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
        else:
            gray_img = self.img
        mask = util.getMask_morphologyEx(gray_img, 400)
        h, w = self.img.shape[:2]
        mask = cv2.resize(mask, (w, h))
        if self.img.shape.__len__() > 2:
            self.img[:, :, 0] = np.where(mask == 1, 0, self.img[:, :, 0])
            self.img[:, :, 1] = np.where(mask == 1, 0, self.img[:, :, 1])
            self.img[:, :, 2] = np.where(mask == 1, 0, self.img[:, :, 2])
        else:
            self.img = np.where(mask == 1, 0, self.img)
        bottom, top, left, right = util.calc_blackborder_with_mask(mask)
        self.top = bottom
        self.left = left
        self.img = self.img[bottom:top, left:right]
        self.img = util.img_resize(self.img, tar_size=self.config['tar_size'])
        if self.img.shape.__len__() == 2:
            self.img = np.expand_dims(self.img, axis=2)
        # if self.img.shape[2] > 1:
        #     self.img = util.color_histogram_match(self.img, ImageGroup.img_ref)

        h, w = self.img.shape[:2]
        mask = mask[bottom:top, left:right]
        mask = cv2.resize(mask, (w, h))
        # self.mask = mask
        self.weight = self.get_weight_with_template(h, w, mask)
        # self.weight = self.get_weight_with_contrast(self.img)
        self.weight *= (1 - mask)
        self.weight = np.expand_dims(self.weight, axis=2)
        # if self.img.shape.__len__() > 2:
        #     self.weight = cv2.cvtColor(self.weight, cv2.COLOR_GRAY2BGR)
        # cv2.imshow('img',self.img)
        # cv2.imshow('weight',self.weight)
        # cv2.waitKey()
        return cv2.resize(gray_img[bottom:top, left:right], (w, h))

    def remove_boundary(self):
        if self.img.shape.__len__() > 2:
            # gray_img = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
            gray_img = self.img[:, :, 1]
            # gray_img = cv2.cvtColor(self.img, cv2.COLOR_BGR2GRAY)
        else:
            gray_img = self.img
        label, mask = util.calc_blackborder_with_connectedComponents(gray_img)
        left, top, w, h = label
        bottom = h + top
        right = w + left
        self.top = top
        self.left = left
        self.img = self.img[top:bottom, left:right]
        self.scale_of_tar = util.calc_resize_scale(self.img.shape, tar_size=self.config['tar_size'])
        self.img = util.img_resize(self.img, tar_size=self.config['tar_size'])
        h, w = self.img.shape[:2]
        self.mask = cv2.resize(mask[top:bottom, left:right], (w, h))
        self.weight = self.get_weight_with_template(h, w, self.mask)
        self.weight = np.expand_dims(self.weight, axis=2)
        if self.img.shape.__len__() == 2:
            self.img = np.expand_dims(self.img, axis=2)
        for i in range(self.img.shape[2]):
            self.img[:, :, i] = self.img[:, :, i] * (1 - self.mask)
        gray_img = cv2.resize(gray_img[top:bottom, left:right], (w, h))
        gray_img = np.where(self.mask == 1, 0, gray_img).astype(np.uint8)
        # a=cv2.resize(gray_img,(0,0),fx=0.25,fy=0.25)
        # b=cv2.resize(self.mask,(0,0),fx=0.25,fy=0.25)
        # c=cv2.resize(self.img,(0,0),fx=0.25,fy=0.25)
        # cv2.imshow('gray_img',a)
        # cv2.imshow('mask',b*255)
        # cv2.imshow('img',c)
        # cv2.waitKey()
        return gray_img

    def get_weight_with_template(self, h, w, mask):
        """
        根据渐变图计算权重
        Args:
            h:
            w:
            mask:

        Returns:

        """
        weight = cv2.resize(ImageGroup.weight_template, (w, h))

        return weight * (1 - mask)

    def get_weight_with_contrast(self, img):
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = torch.from_numpy(img).unsqueeze(0).unsqueeze(0).float()
        down_sampled = torch.nn.functional.max_pool2d(img, kernel_size=4)
        up_sampled = torch.nn.functional.interpolate(down_sampled, size=img.shape[2:], mode='nearest')
        img1 = up_sampled[0][0].numpy().astype(np.uint8)
        # cv2.imshow('img', img1)
        # cv2.waitKey()
        return torch.abs(img - up_sampled)[0][0].numpy().astype(np.uint8) + 1

    def get_channel(self):
        if self.img.shape.__len__() > 2:
            return self.img.shape[2]
        return 1

    def get_img_name(self):
        if self.img_name is None:
            self.img_name = os.path.basename(self.img_path)
        return self.img_name

    def get_is_CFP(self):
        if self.is_CFP == None:
            if self.get_channel() == 3:
                if np.sum(self.img[:, :, 0] != self.img[:, :, 1]) > 0.10 * self.img.shape[0] * self.img.shape[1]:
                    self.is_CFP = True
                    return self.is_CFP
            self.is_CFP = False
        return self.is_CFP

    def check(self):
        cv2.imshow('img', skimage.transform.warp(self.img, self.scale_tform, output_shape=(512, 780),
                                                 preserve_range=True).astype(np.uint8))
        # cv2.imshow('mask',util.img_resize(self.mask,512)*255)
        cv2.imshow('I', self.I)
        cv2.imshow('Imask', self.Imask * 255)
        cv2.waitKey()
