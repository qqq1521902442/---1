import copy
import datetime
import os

import cv2
import skimage

import numpy as np

from FPRegistration import util, ImageWarp
from FPRegistration.ImageGroup import ImageGroup, ImageWeightAndCoord
from concurrent.futures import ThreadPoolExecutor, wait, ALL_COMPLETED, FIRST_COMPLETED
from icecream import ic


class DataGroup():
    def __init__(self, config):

        self.time_vegan_total = datetime.timedelta()
        self.config = config
        # self.img_paths = img_paths
        self.img_groups = []
        self.time_kp_detect = datetime.timedelta()
        self.time_set_img = datetime.timedelta()
        self.time_read = datetime.timedelta()
        self.time_mask = datetime.timedelta()
        self.time_match = datetime.timedelta()
        self.time_save = datetime.timedelta()
        self.time_merge = datetime.timedelta()
        self.time_bj = datetime.timedelta()
        self.time_vegan = datetime.timedelta()
        self.time_warp = datetime.timedelta()
        self.time_order = datetime.timedelta()
        self.time_write = datetime.timedelta()
        self.match_flag = None
        # right，bottom表示结果图的shape
        self.right = 0
        self.bottom = 0
        self.tforms_added_border = None
        self.tforms = []
        self.task_list = []

    def set_img_(self, img_paths, model_vegan, model_bj):
        time = datetime.datetime.now()
        cfp_num = 0
        for id, img_path in enumerate(img_paths):
            img_group = ImageGroup(id, img_path, self.config)
            self.img_groups.append(img_group)
            cfp_num += img_group.get_is_CFP()
        change_flag = (cfp_num != len(img_paths))
        if not self.config['initial_in_thread']:
            for img_group in self.img_groups:
                img_group.initial(change_flag, model_vegan, model_bj)
        self.time_set_img = datetime.datetime.now() - time
        return change_flag

    def set_img_paths(self, img_paths, model_vegan, model_bj):
        time = datetime.datetime.now()
        sub_img_groups = []
        gray_imgs = []
        for id, img_path in enumerate(img_paths):
            img_group = ImageGroup(id, img_path, self.config)
            if img_group.get_channel() == 3:
                if np.sum(img_group.img[:, :, 0] != img_group.img[:, :, 1]) > 0.10 * img_group.img.shape[0] * \
                        img_group.img.shape[1]:
                    sub_img_groups.append(img_group)
                gray_img = cv2.cvtColor(img_group.img, cv2.COLOR_BGR2GRAY)
                # gray_img = img_group.img[:,:,1]
            else:
                gray_img = img_group.img
            img_group.I = gray_img
            gray_imgs.append(gray_img)
        self.time_read = datetime.datetime.now() - time
        is_OSs, self.time_bj = model_bj.calc_osod(gray_imgs, img_paths, self.config['bj_size'])
        time1 = datetime.datetime.now()
        if self.config['do_exchange'] and len(sub_img_groups) != len(self.img_groups):
            sub_imgs = []
            sub_img_paths = []
            for sub_img_group in sub_img_groups:
                sub_imgs.append(sub_img_group.img)
                sub_img_paths.append(sub_img_group.img_path)
            fitted_imgs, paths, self.time_vegan = model_vegan.convert_img(sub_imgs, sub_img_paths)
            for fitted_img, path, sub_img_group in zip(fitted_imgs, paths, sub_img_groups):
                assert path == sub_img_group.img_path
                sub_img_group.I = fitted_img
        self.time_vegan_total = datetime.datetime.now() - time1
        time1 = datetime.datetime.now()
        for (img_group, gray_img, is_OS) in zip(self.img_groups, gray_imgs, is_OSs):
            img_group.I = util.img_resize(img_group.I, self.config['fit_size'])
            img_group.Imask = util.getMask(gray_img, self.config['fit_size'])
            mask = util.img_resize(np.where(img_group.Imask == 1, 0, 1).astype(np.uint8), img_group.img.shape[0])
            # mask = cv2.resize(np.where(img_group.Imask == 1, 0, 1).astype(np.uint8), img_group.img.shape[:2])
            if img_group.get_channel() == 3:
                mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
                mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
            img_group.mask = mask
            if self.config['tar_size'] == -1:
                img_group.scale = img_group.img.shape[0] / self.config['fit_size']
                img_group.scale_tform = skimage.transform.AffineTransform()
            else:
                img_group.scale = self.config['tar_size'] / self.config['fit_size']
                scale = img_group.img.shape[0] / self.config['tar_size']
                img_group.scale_tform = skimage.transform.AffineTransform(scale=(scale, scale))
            img_group.is_OS = is_OS
        self.time_mask = datetime.datetime.now() - time1
        self.time_set_img = datetime.datetime.now() - time
        # for img_group in self.img_groups:
        #     img_group.check()

    def set_img_groups(self, img_groups):
        self.img_groups = img_groups

    # todo 功能函数

    # def get_merged_img(self, img_groups):
    #     time = datetime.datetime.now()
    #     max_channel = 1
    #     for img_group in img_groups:
    #         if img_group.get_channel() > max_channel:
    #             max_channel = img_group.get_channel()
    #     shape = self.right_down_border.astype(np.int32)
    #
    #     if max_channel == 3:
    #         shape = (shape[0], shape[1], 3)
    #         for img_group in img_groups:
    #             if img_group.warped_img.shape.__len__() == 2 or img_group.warped_img.shape[2] == 1:
    #                 img_group.warped_img = cv2.cvtColor(img_group.warped_img, cv2.COLOR_GRAY2BGR)
    #             if img_group.warped_mask.shape.__len__() == 2 or img_group.warped_mask.shape[2] == 1:
    #                 img_group.warped_mask = cv2.cvtColor(img_group.warped_mask, cv2.COLOR_GRAY2BGR)
    #     maskk = np.zeros(shape, dtype=np.uint8)
    #     for img_group in img_groups:
    #         maskk += img_group.warped_mask
    #     merge = np.zeros(shape, dtype=np.uint8)
    #     for img_group in img_groups:
    #         warped_mask = img_group.warped_mask
    #         warped_img = img_group.warped_img
    #         merge = merge + 1.0 * warped_mask / (maskk + 0.000001) * warped_img
    #     self.time_merge = datetime.datetime.now() - time
    #     return merge.astype(np.uint8)

    # def warp_img(self):
    #     time_warp = datetime.datetime.now()
    #     img_group0 = self.img_groups[self.task_list[0]]
    #     to_right, to_bottom = img_group0.to_right, img_group0.to_bottom
    #     right, bottom = self.right, self.bottom
    #     for i, img_group in enumerate(self.img_groups):
    #         if img_group.transform is None:
    #             continue
    #         if i == self.task_list[0]:
    #             left, top = to_right, to_bottom
    #         else:
    #             left, top = to_right - img_group.to_right, to_bottom - img_group.to_bottom
    #         img_c = np.concatenate((img_group.img, img_group.weight), axis=2)
    #         warped_img = img_group.transform.warp_img(left, top, right, bottom, img_c)
    #         img_group.warped_img = warped_img[:, :, 0:-1]
    #         img_group.warped_weight = warped_img[:, :, -1:]
    #     self.time_warp = datetime.datetime.now() - time_warp

    def warp_img_thread_pool(self):
        time_warp = datetime.datetime.now()
        img_group0 = self.img_groups[self.task_list[0]]
        left, top = img_group0.to_right, img_group0.to_bottom
        # right, bottom = self.right, self.bottom
        thread_pool = ThreadPoolExecutor(max_workers=self.config['thread_pool_size'])
        results = []
        for i, img_group in enumerate(self.img_groups):
            if img_group.transform is None:
                continue
            if i == self.task_list[0]:
                to_right, to_bottom = left, top
            else:
                to_right, to_bottom = left - img_group.to_right, top - img_group.to_bottom
            results.append(thread_pool.submit(ImageWarp.warp_img_one_thread(img_group, to_right, to_bottom)))
            # print('warp_thread',i)
        wait(results, return_when=ALL_COMPLETED)
        thread_pool.shutdown(wait=True)
        self.time_warp = datetime.datetime.now() - time_warp

    def write_img(self, save_path):
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        time_write = datetime.datetime.now()
        img_path_list = []
        for i, img_group in enumerate(self.img_groups):
            if img_group.transform is None:
                continue
            img_path = os.path.join(save_path, img_group.get_img_name())
            util.imwrite(img_path, img_group.iwac.get_output(self.right, self.bottom), '.jpg')
            img_path_list.append(img_path)
        self.time_write = datetime.datetime.now() - time_write
        return img_path_list

    def write_merged_img_stitcher(self, master_id, save_path):
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        time_merge = datetime.datetime.now()
        imgs = []
        for i, img_group in enumerate(self.img_groups):
            if i == master_id or img_group.transform is None:
                continue
            imgs.append(img_group.warped_img)

        # modes = (cv2.Stitcher_PANORAMA, cv2.Stitcher_SCANS)
        stitcher = cv2.Stitcher.create(1)
        status, pano = stitcher.stitch(imgs)
        if status != cv2.Stitcher_OK:
            print("Can't stitch images, error code = %d" % status)
            return

        util.imwrite(save_path + '/final.png', pano, '.png')
        self.time_merge = datetime.datetime.now() - time_merge

    def calc_total_cdf(self):
        # 计算所有图像的累积分布
        total_hist_3channel = []
        total_hist_1channel = []
        for i, img_group in enumerate(self.img_groups):
            if img_group.transform is None:
                continue
            x, y, hist_list = img_group.iwac.get_histogram()
            if len(hist_list) == 1:
                if len(total_hist_1channel) == 0:
                    total_hist_1channel += copy.deepcopy(hist_list)
                else:
                    total_hist_1channel[0] += hist_list[0]
            elif len(hist_list) == 3:
                if len(total_hist_3channel) == 0:
                    total_hist_3channel += copy.deepcopy(hist_list)
                else:
                    total_hist_3channel[0] += hist_list[0]
                    total_hist_3channel[1] += hist_list[1]
                    total_hist_3channel[2] += hist_list[2]
        # util.hist_equalize(total_hist_3channel[0])
        # util.hist_equalize(total_hist_3channel[1])
        # util.hist_equalize(total_hist_3channel[2])
        # if len(total_hist_1channel) ==1:
        #     util.hist_equalize(total_hist_1channel[0],0.01)
        total_cdf_3channel = []
        total_cdf_1channel = []
        # 计算原始图像累积分布函数 CDF
        if len(total_hist_3channel) != 0:
            total_cdf_3channel.append(
                np.cumsum(total_hist_3channel[0]) / np.sum(total_hist_3channel[0]))
            total_cdf_3channel.append(
                np.cumsum(total_hist_3channel[1]) / np.sum(total_hist_3channel[1]))
            total_cdf_3channel.append(
                np.cumsum(total_hist_3channel[2]) / np.sum(total_hist_3channel[2]))
        if len(total_hist_1channel) != 0:
            total_cdf_1channel.append(
                np.cumsum(total_hist_1channel[0]) / np.sum(total_hist_1channel[0]))
        return total_cdf_3channel, total_cdf_1channel

    def write_merged_img(self, save_path, img_name):
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        time_merge = datetime.datetime.now()

        total_cdf_3channel, total_cdf_1channel = self.calc_total_cdf()
        channel = 1
        for i, img_group in enumerate(self.img_groups):
            if img_group.transform is None:
                continue
            channel = max(channel, img_group.img.shape[2])
        canvas = np.zeros((self.bottom, self.right, channel))
        weight = np.zeros((self.bottom, self.right, channel))
        # warped_img, warped_weight = self.img_groups[master_id].iwac.get_output(self.right, self.bottom,
        #                                                                        flag=2)

        for i, img_group in enumerate(self.img_groups):
            if img_group.transform is None:
                continue
            # warped_img, warped_weight = util.merge_with_ImageWeightAndCoord(img_group.iwac, warped_img,
            #                                                                 warped_weight, 'merge_max_weight')
            canvas, weight = util.merge_with_IWAC_and_cdf(img_group.iwac, canvas,
                                                          weight, total_cdf_3channel,
                                                          total_cdf_1channel, 'merge_max_weight')

            if ic.enabled:
                iwac = ImageWeightAndCoord(img_group.img, img_group.weight, 0, 0, 0, 0)
                iwac.hist_matched_img = None
                util.imwrite('outs/no_border/' + str(i) + '_.jpg',
                             iwac.get_hist_matched_img(total_cdf_3channel, total_cdf_1channel), '.jpg')

            # util.merge_max_weight(warped_img, img_group.warped_img, warped_weight,
            #                                               img_group.warped_weight)
            # warped_img = util.Lighten_gray(warped_img, img_group.warped_img)
            # warped_img = util.Lighten(warped_img, img_group.warped_img)
        path = os.path.join(save_path, img_name)
        util.imwrite(path, canvas, os.path.splitext(path)[-1])
        if ic.enabled:
            util.imwrite(path + '.jpg', weight, os.path.splitext(path)[-1])
        self.time_merge = datetime.datetime.now() - time_merge
        return path

    def get_merged_img_color_burn(self, img_groups, method='Lighten'):
        time = datetime.datetime.now()
        max_channel = 1
        for img_group in img_groups:
            if img_group.get_channel() > max_channel:
                max_channel = img_group.get_channel()
        shape = self.right_down_border.astype(np.int32)

        if max_channel == 3:
            shape = (shape[0], shape[1], 3)
            for img_group in img_groups:
                if img_group.warped_img.shape.__len__() == 2 or img_group.warped_img.shape[2] == 1:
                    img_group.warped_img = cv2.cvtColor(img_group.warped_img, cv2.COLOR_GRAY2BGR)

        merge = np.zeros(shape)
        if method == 'Lighten':
            for img_group in img_groups:
                merge = util.Lighten(merge, img_group.warped_img)
        else:
            maskk = np.zeros(shape, dtype=np.uint8)
            for img_group in img_groups:
                maskk += img_group.warped_mask
            for img_group in img_groups:
                warped_mask = img_group.warped_mask
                warped_img = img_group.warped_img
                merge = merge + 1.0 * warped_mask / (maskk + 0.000001) * warped_img

        # cv2.imshow('merge',merge.astype(np.uint8))
        # cv2.waitKey()
        self.time_merge = datetime.datetime.now() - time
        return merge.astype(np.uint8)

    def get_output(self):
        time = datetime.datetime.now()
        img_groups = []
        for i, (tform, img_group) in enumerate(zip(self.tforms_added_border, self.img_groups)):
            if tform is None:
                continue
            img = img_group.img
            mask = img_group.mask
            img_group.warped_img = (
                skimage.transform.warp(img, tform, output_shape=self.right_down_border.astype(np.int32),
                                       preserve_range=True)).astype(np.uint8)
            img_group.warped_mask = (
                skimage.transform.warp(mask, tform, output_shape=self.right_down_border.astype(np.int32),
                                       preserve_range=True)).astype(np.uint8)
            img_groups.append(img_group)
        self.time_warp = datetime.datetime.now() - time
        return img_groups

    def save_img(self, img_groups, save_dir, merged_img=None):
        if (not os.path.exists(save_dir)):
            os.makedirs(save_dir)
        time = datetime.datetime.now()
        if merged_img is None:
            save_paths = []
        else:
            write_path = os.path.join(os.path.join(save_dir, 'merged.png'))
            util.imwrite(write_path, merged_img, os.path.splitext(write_path)[-1])
            save_paths = ['merged.bmp']
        for i, img_group in enumerate(img_groups):
            write_path = os.path.join(os.path.join(save_dir, img_group.get_img_name()))
            util.imwrite(write_path, img_group.warped_img, os.path.splitext(write_path)[-1])
            save_paths.append(write_path)
        self.time_save = datetime.datetime.now() - time
        return save_paths

    def get_sub_dataGroup(self):
        sub_img_groups = []
        for img_group in self.img_groups:
            if img_group.transform is None:
                sub_img_groups.append(img_group)
        sub_dataGroup = DataGroup(self.config)
        sub_dataGroup.set_img_groups(sub_img_groups)
        return sub_dataGroup

    def calc_eye_pos(self, img_groups):
        avg = self.calc_prob_is_OS(img_groups)
        # print('avg',avg)
        if avg > 0.5:
            return 'OS'
        return 'OD'

    def calc_eye_pos_(self):
        sum, count = 0, 0
        for img_group in self.img_groups:
            if img_group.transform is not None:
                sum += img_group.is_OS
                count += 1
        if count == 0:
            return "OS"
        avg = sum / count
        # print('avg',avg)
        if avg > 0.5:
            return 'OS'
        return 'OD'

    def calc_prob_is_OS(self, img_groups):
        sum = 0
        for img_group in img_groups:
            sum += img_group.is_OS
            # print(img_group.id,img_group.is_OS)
        avg = sum / len(img_groups)
        return avg

    # todo show
    def show_point_all(self):
        for i, img in enumerate(self.Is):
            img = util.draw_keypoints(img, self.detected_datas[i]['keypoints'][0].cpu().numpy())
            cv2.imshow(i.__str__(), img)
            cv2.imshow(i.__str__() + 'mask', self.masks[i] * 255)
        cv2.waitKey()

    # todo 设置参数
    def set_img(self, imgs, masks, Is, Imasks, scales):
        self.imgs = imgs
        self.masks = masks
        self.Is = Is
        self.Imasks = Imasks
        self.scales = scales

    def set_detected_datas(self, detected_datas):
        self.detected_datas = detected_datas

    def set_time_kp_detect(self, time):
        self.time_kp_detect = time

    def set_tforms(self, tforms):
        self.tforms = tforms

    def set_tforms_added_border(self, tforms_added_border):
        self.tforms_added_border = tforms_added_border

    def set_time_match(self, time):
        self.time_match = time

    def set_match_flag(self, match_flag):
        self.match_flag = match_flag

    def set_right_down_border(self, right_down_border):
        self.right_down_border = right_down_border

    # def set_border(self, left_up_border, right_down_border):
    #     self.left_up_border = left_up_border
    #     self.right_down_border = right_down_border
    #     self.tforms_added_border = []
    #     if np.max(left_up_border) > 0:
    #         for i in range(len(self.img_groups)):
    #             if self.tforms[i] is None:
    #                 self.tforms_added_border.append(None)
    #                 continue
    #             self.tforms_added_border.append(util.calc_tform_with_leftupBorder(self.tforms[i], left_up_border))
    #     else:
    #         self.tforms_added_border = self.tforms
    # def set_tform(self,tforms):
    #     self.tforms=tforms

    # def merge_imgs(self, outs, masks, shape):
    #     shape = (shape[0], shape[1], 3)
    #     maskk = np.zeros(shape, dtype=np.uint8)
    #     for i, (out, mask) in enumerate(zip(outs, masks)):
    #         if mask.shape.__len__() == 2 or mask.shape[2] == 1:
    #             # cv2.imshow('maskb',mask)
    #             mask = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)
    #             # cv2.imshow('maskl',mask)
    #             # cv2.waitKey()
    #             masks[i] = mask
    #         if out.shape.__len__() == 2 or out.shape[2] == 1:
    #             out = cv2.cvtColor(out, cv2.COLOR_GRAY2BGR)
    #             outs[i] = out
    #         maskk = maskk + mask
    #     merge = np.zeros(shape, dtype=np.uint8)
    #     # a = cv2.cvtColor(outs[0], cv2.COLOR_BGR2GRAY)
    #     # for i, out in enumerate(outs):
    #     #     if (i > 0):
    #     #         mask_x=np.logical_and(mask[0],mask[i])
    #     #
    #     #         b = cv2.cvtColor(out, cv2.COLOR_BGR2GRAY)
    #     #
    #     #         R = regist_BSpline(a, b)
    #     #         out1 = R.do_registration()
    #     #         cv2.imshow('out1', out1)
    #     #         cv2.imshow('a', a)
    #     #         cv2.imshow('b', b)
    #     #         cv2.waitKey(0)
    #     #         for i in range(3):
    #     #             out1[:, :, i] = R.registrationFromMatrix(out[:, :, i])
    #     #         outs[i]=out1
    #     for i, out in enumerate(outs):
    #         merge = (merge + 1.0 * masks[i] / (maskk + 0.000001) * out).astype(np.uint8)
    #
    #         # cv2.imshow('mask', masks[i] * 255)
    #         # cv2.imshow('out', out)
    #         # cv2.imshow('dd', (1.0 * masks[i] / (maskk + 0.000001) * out).astype(np.uint8))
    #         # cv2.imshow('merge', merge.astype(np.uint8))
    #         # cv2.waitKey()
    #     return merge.astype(np.uint8)
