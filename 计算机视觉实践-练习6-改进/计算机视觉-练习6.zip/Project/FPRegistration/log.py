import logging
from logging.handlers import TimedRotatingFileHandler
import re
import os

# def setup_custom_logger(name):
#     logging.basicConfig()
#     logger = logging.getLogger(name)
#     logger.setLevel(logging.INFO)
#     formatter = logging.Formatter(
#         fmt='%(asctime)s - %(levelname)s - %(module)s - %(message)s')
#
#     consoleHandler = logging.StreamHandler()
#     consoleHandler.setLevel(logging.INFO)
#     consoleHandler.setFormatter(formatter)
#     logger.addHandler(consoleHandler)
#     return logger


# def logger_config(log_path,logging_name):
#     '''
#     配置log
#     :param log_path: 输出log路径
#     :param logging_name: 记录中name，可随意
#     :return:
#     '''
#     '''
#     logger是日志对象，handler是流处理器，console是控制台输出（没有console也可以，将不会在控制台输出，会在日志文件中输出）
#     '''
#     # 获取logger对象,取名
#     logger = logging.getLogger(logging_name)
#     # 输出DEBUG及以上级别的信息，针对所有输出的第一层过滤
#     logger.setLevel(level=logging.DEBUG)
#     # 获取文件日志句柄并设置日志级别，第二层过滤
#     handler = logging.FileHandler(log_path, encoding='UTF-8')
#     handler.setLevel(logging.INFO)
#     # 生成并设置文件日志格式
#     formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
#     handler.setFormatter(formatter)
#     # console相当于控制台输出，handler文件输出。获取流句柄并设置日志级别，第二层过滤
#     console = logging.StreamHandler()
#     console.setLevel(logging.DEBUG)
#     # 为logger对象添加句柄
#     logger.addHandler(handler)
#     logger.addHandler(console)
#     return logger

def setup_log(log_path,log_name):
    assert os.path.exists(log_path)
    # 创建logger对象。传入logger名字
    logger = logging.getLogger(log_name)
    log_path = os.path.join(log_path,log_name)
    # 设置日志记录等级
    logger.setLevel(logging.INFO)
    # interval 滚动周期，
    # when="MIDNIGHT", interval=1 表示每天0点为更新点，每天生成一个文件
    # backupCount  表示日志保存个数
    file_handler = TimedRotatingFileHandler(
        filename=log_path, when="MIDNIGHT", interval=1, backupCount=30
    )
    # filename="mylog" suffix设置，会生成文件名为mylog.2020-02-25.log
    file_handler.suffix = "%Y-%m-%d.log"
    # extMatch是编译好正则表达式，用于匹配日志文件名后缀
    # 需要注意的是suffix和extMatch一定要匹配的上，如果不匹配，过期日志不会被删除。
    file_handler.extMatch = re.compile(r"^\d{4}-\d{2}-\d{2}.log$")
    # 定义日志输出格式
    file_handler.setFormatter(
        logging.Formatter(
            "[%(asctime)s] [%(process)d] [%(levelname)s] - %(module)s.%(funcName)s (%(filename)s:%(lineno)d) - %(message)s"
        )
    )
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    logger.addHandler(file_handler)
    logger.addHandler(console)
    return logger
