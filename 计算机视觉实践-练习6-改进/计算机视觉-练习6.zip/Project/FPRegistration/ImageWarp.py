import numpy as np

from FPRegistration.ImageGroup import ImageWeightAndCoord


def warp_img_one_thread(img_group, left, top):
    img_c = np.concatenate((img_group.img, img_group.weight), axis=2)
    warped_img, left_, top_, shape_r, shape_b = img_group.transform.warp_img_remove_border(left, top, img_c)
    # img_group.warped_img = warped_img[:, :, 0:-1]
    # img_group.warped_weight = warped_img[:, :, -1:]
    img_group.iwac = ImageWeightAndCoord(warped_img[:, :, 0:-1], warped_img[:, :, -1:], left_, top_,
                                         shape_r, shape_b)
